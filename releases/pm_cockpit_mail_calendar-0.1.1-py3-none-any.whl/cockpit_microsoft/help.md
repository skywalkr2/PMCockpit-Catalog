# Microsoft: Outlook mail and calendar

## Signing in

You sign in to Microsoft on Microsoft's own page, so PM Cockpit never sees your password. There is nothing to register
first: the add-on comes with the publisher's app registration.

1. Open Add-ons and turn the add-on on.
2. Open Settings, then Sign-ins, and choose Sign in next to Microsoft.
3. PM Cockpit lists what you will be asked to allow. Then you go to Microsoft's page: check the account and the list,
   and allow it.

When you come back, the row shows which account is signed in.

A work or school account may need its administrator to approve the app before you can sign in. Ask them to grant
admin consent for it. To limit sign-ins to one organization, set `tenant` in `config/plugins/microsoft.yaml`.

### Using your own app registration

You can use an app registration of your own instead. It suits an organization that wants its own, for example so that
its administrator approves one app that it controls. On the Microsoft row under Settings, Sign-ins, paste your
Application (client) ID, following the steps listed there. They register a new app in Microsoft Entra that accepts
accounts in any organizational directory and personal Microsoft accounts, add the address shown there as a Public
client (mobile and desktop) redirect, and add the delegated Microsoft Graph permissions Mail.Read, Calendars.Read,
User.Read and offline_access. Don't create a client secret.

## What it can read and what it can't

PM Cockpit shows you these lines before you sign in:

- Read your mail (it can't send, delete or change anything)
- Read your calendars (it can't add or change events)
- See your name and email address, to show which account is signed in
- Stay signed in, so it can keep reading while you're away

It only reads. It never sends mail, deletes anything, marks mail read, moves mail, or adds or changes events. The
permission to see your name is used only to show which account is signed in. If a permission isn't allowed when you
sign in, the Sign-ins row names it, and reading that part stops with a message to sign in again.

The calendar fills Today's agenda, and mail fills what came in today. Whether a message has been opened or is unread
is shown there, but it is never treated as a change for the assistant.

Signing in reads your whole inbox. PM Cockpit sets aside mailing-list and bulk mail in its Set aside folder without
spending an AI run on it. You can see it there and mark a message as work.

## Choosing what to read

Signing in starts reading your inbox, your sent mail and your calendar, every 15 minutes. You can narrow, add or remove sources on PM
Cockpit's sources screen or in `config/watch.yaml`. A mail source with no folders reads your inbox. Once you name
folders, it reads only what you choose. A folder can be:

- a well-known name: `inbox`, `archive`, `sentitems`, `drafts`, `deleteditems` or `junkemail`;
- a folder's name, such as `Receipts`;
- a path, such as `Inbox/Projects`.

If you rename a folder you chose, it is still read. After the first read, only what changed is read. Messages that are
deleted or moved out of the folder are reported as gone. Drafts are left out.

Calendar: with no `calendars` named, it reads your default calendar. Name others to read those. Events are read in a
window around today (`days_back`, `days_ahead`).

By default the first read of a source only notes what is there, and later reads hand in what is new or changed. Set
`first_run: all` on the source to hand in everything on the first read. Example `config/watch.yaml` sources:

```yaml
sources:
  - id: alpha-mail
    connector: microsoft/mail
    label: Alpha project mail
    every_minutes: 30
    settings:
      folders: [Inbox/Projects]
  - id: inbox
    connector: microsoft/mail
    label: Inbox
    settings:
      folders: [inbox]
      days_back: 7
  - id: team-calendar
    connector: microsoft/calendar
    label: Team calendar
    settings:
      calendars: [Team planning]
      days_ahead: 30
```

## When it asks you to sign in again

PM Cockpit asks once, and shows Sign in again on the row, when:

- Microsoft refuses to renew your sign-in.
- You withdrew the access at Microsoft (see "Withdrawing access").
- A permission wasn't allowed when you signed in. The message says "Reading mail wasn't allowed when you signed in.
  Sign in again and allow it." (or the same for your calendar).

To fix it, open Settings, Sign-ins, choose Sign in again, and allow everything on Microsoft's page. The question
closes by itself once you are signed in.

## Withdrawing access

Signing out in Settings, Sign-ins, forgets the sign-in on this computer. Microsoft offers no way to withdraw the access
from here, so the app keeps its permission on your account until you remove it yourself:

- Work or school account: <https://myapps.microsoft.com/>, choose the app, then choose Revoke.
- Personal account: <https://account.live.com/consent/Manage>, choose the app, then choose Remove.

## Limits and waiting

Each limit is a setting on the source, and every one has a default.

Mail:

- `days_back` (14): how far back the first read goes.
- `max_messages_per_read` (200): the most messages one read takes. The rest wait for the next read.
- `max_pages_per_read` (20): the most pages one read asks Microsoft for, folder lookups included.
- `max_body_chars` (8000): how much of a message's text is kept.
- `attachment_names` (on): whether to list attachment names. This costs one request for each message with attachments.
- `max_attachment_lookups_per_read` (50): the most messages per read whose attachment names are looked up.

Calendar:

- `days_back` (7) and `days_ahead` (60): the window of events.
- `max_events_per_read` (500) and `max_pages_per_read` (20): the most events and pages one read takes.
- `max_description_chars` (4000): how much of an event's description is kept.

When Microsoft says "please wait" (too many requests), PM Cockpit waits as long as Microsoft asks and doesn't count it
as a failure. It never retries in a loop.

## Filtering mailing lists and automatic replies

Three rule kinds close a change before the assistant reads it. You can see what they closed, and why, under
Auto-closed, and take a closer look at any of it.

- `microsoft/mailing-lists` closes new or changed mail sent to a mailing list. The optional `keep_from` lists
  addresses or `@domain`s whose list mail you still want.
- `microsoft/automatic-replies` closes new or changed mail that is an automatic reply, such as an out-of-office note.
- `microsoft/answers-only` closes a changed event when only attendees' answers changed. It leaves alone an event where
  someone was added or removed.

Mail is marked from its own headers, never from the subject or the text. A message gets the line "Sent as: mailing
list" or "Sent as: automatic reply" when its headers say so, and the rules read that line. If Outlook doesn't send a
message's headers, the message gets no line and these rules leave it alone. Example in `config/watch.yaml`:

```yaml
triage:
  - name: Skip mailing lists
    kind: microsoft/mailing-lists
    params:
      keep_from: ["lead@example.com", "@client.example.com"]
    sources: [inbox]
  - name: Skip automatic replies
    kind: microsoft/automatic-replies
  - name: Skip answers to invitations
    kind: microsoft/answers-only
    sources: [team-calendar]
```
