"""The Gmail connector: messages under the labels the person names, or matching a search, read through the Gmail
API. Read-only.

With no label and no search named, it reads the label INBOX, in label mode. There are two modes:

- Label mode (no search): the first read lists each label's recent messages, and later reads follow the mailbox's
  history from a saved `historyId`, taking the changes that touch a chosen label (with `track_unread`, a message
  already read in that is opened or marked unread is taken again, so Today's unread mark follows; the ids read in
  are kept in `known`). Messages deleted, or no longer
  under a chosen label, are handed in as removed. History can't be narrowed by a search, so a search can't be used
  with it.
- Search mode: each read lists the messages that match the search and arrived since the last read (with an overlap
  for late arrivals). The ids already fetched in the overlap are remembered and not fetched again. No removals: a
  search can't tell a message that left it from one that was never there.

Listing returns only ids, so the ids wait in `state` and each message is fetched on its own, up to a cap per read.
Only GET requests are made, and `format=full` doesn't mark anything read.
"""

from __future__ import annotations

import base64
import binascii
import contextlib
import re
from collections.abc import Iterator
from datetime import UTC, date, datetime, time, timedelta
from email import errors
from email.header import decode_header, make_header
from email.utils import getaddresses
from typing import Any
from urllib.parse import quote

from engine.plugin_api import ConnectorError, MessageDetails, Poll, SourceItem
from pydantic import BaseModel, ConfigDict, Field

from cockpit_mail_calendar_common import clip, html_to_text, require_scope
from cockpit_mail_calendar_common.triage import bulk, sent_as

from .api import GMAIL, SIGN_IN, Reader, find_by_name, person
from .sign_in import MAIL_API_OFF, MAIL_NOT_ALLOWED, MAIL_SCOPE

LIST_PAGE = "100"
HISTORY_PAGE = "500"
UNREAD = "UNREAD"
INBOX = "INBOX"
_CHARSET = re.compile(r"charset\s*=\s*\"?([A-Za-z0-9_.:-]+)", re.I)


class MailSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    labels: list[str] = Field(
        default_factory=list,
        description=(
            "Labels to read, by name (INBOX, Projects/Alpha). A message with any of them is read. "
            "Empty, with no search, means your inbox."
        ),
    )
    query: str = Field(
        "",
        description=(
            "A Gmail search, such as: from:client.example.com has:attachment. When set, each read lists the matching "
            "messages that arrived since the last read, instead of following changes. With labels too, a message "
            "must have one of the labels and match the search."
        ),
    )
    days_back: int = Field(
        14, ge=0, le=365, description="How many days back the first read goes. Later reads take only what is new."
    )
    max_messages_per_read: int = Field(
        100, ge=1, le=2000, description="The most messages one read fetches and hands in. The rest wait."
    )
    max_pages_per_read: int = Field(
        20,
        ge=1,
        le=200,
        description="The most list, history and label pages one read asks the service for. The rest wait.",
    )
    max_waiting: int = Field(
        5000,
        ge=100,
        le=50000,
        description="The most message ids kept waiting between reads. Past this, the oldest are dropped.",
    )
    search_overlap_minutes: int = Field(
        60,
        ge=0,
        le=1440,
        description="With a search: how far before the last read each read looks again, to catch late arrivals.",
    )
    max_body_chars: int = Field(
        8000, ge=0, le=100000, description="How much of a message's text is kept. 0 keeps none."
    )
    track_unread: bool = Field(
        True,
        description=(
            "Keep Today's unread marks current. Costs one request per message opened or marked unread. "
            "Only messages already read in are refreshed, and only with labels: a search does not track this."
        ),
    )
    throttle_wait_seconds: int = Field(
        60,
        ge=1,
        le=3600,
        description=(
            "Seconds to wait before reading again when Google says there are too many requests but not for how long."
        ),
    )


def _today() -> date:
    return datetime.now(UTC).date()


def _now() -> datetime:
    return datetime.now(UTC)


def _decoded(value: str) -> str:
    """A header value with any encoded words (`=?UTF-8?B?...?=`) decoded and its folding turned into spaces."""
    with contextlib.suppress(errors.MessageError, LookupError, UnicodeError, ValueError):
        value = str(make_header(decode_header(value)))
    return " ".join(value.split())


def _addresses(value: str) -> list[tuple[str, str]]:
    return [(_decoded(name), address.strip()) for name, address in getaddresses([value]) if name or address]


def _people(value: str) -> str:
    """An address header as `Name <address>, ...`."""
    shown = [person({"displayName": name, "email": address}) for name, address in _addresses(value)]
    return ", ".join(name for name in shown if name)


def _headers(part: dict[str, Any]) -> dict[str, str]:
    """A part's headers by lower-case name (the first one wins when a name repeats)."""
    found: dict[str, str] = {}
    for header in part.get("headers") or []:
        if isinstance(header, dict) and header.get("name"):
            found.setdefault(str(header["name"]).casefold(), str(header.get("value") or ""))
    return found


def _parts(part: dict[str, Any]) -> Iterator[dict[str, Any]]:
    """A part and then, in order, all the parts nested in it."""
    yield part
    for child in part.get("parts") or []:
        if isinstance(child, dict):
            yield from _parts(child)


def _decode_part(part: dict[str, Any]) -> str | None:
    """A part's text: its base64url data decoded as the charset its Content-Type names (utf-8 when none is named or
    known, with undecodable bytes replaced). None when the part holds no data."""
    data = str((part.get("body") or {}).get("data") or "")
    if not data:
        return None
    try:
        raw = base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))
    except (binascii.Error, ValueError):
        return None
    found = _CHARSET.search(_headers(part).get("content-type", ""))
    try:
        return raw.decode(found.group(1) if found else "utf-8", errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


def _body(payload: dict[str, Any], max_chars: int) -> str:
    """The message text: the first plain-text part, or else the first HTML part as text. A part that is an attachment
    (it has a file name) isn't the body."""
    plain = html = None
    for part in _parts(payload):
        kind = str(part.get("mimeType") or "").casefold()
        text = _decode_part(part) if kind in ("text/plain", "text/html") and not part.get("filename") else None
        if text is None:
            continue
        if kind == "text/plain":
            plain = text
            break
        html = html if html is not None else text
    if plain is not None:
        return clip(plain.replace("\r\n", "\n").replace("\r", "\n").strip(), max_chars)
    return html_to_text(html, max_chars) if html is not None else ""


def _attachments(payload: dict[str, Any]) -> str:
    """The file names of the attachments. Inline parts (pictures in the text) are left out: a part marked inline, or
    one with a Content-ID that isn't marked as an attachment (Gmail adds a Content-ID to some real attachments)."""
    names = []
    for part in _parts(payload):
        name = str(part.get("filename") or "").strip()
        if not name:
            continue
        headers = _headers(part)
        disposition = headers.get("content-disposition", "").strip().casefold()
        if disposition.startswith("inline") or ("content-id" in headers and not disposition.startswith("attachment")):
            continue
        names.append(name)
    return ", ".join(names)


def _moment(message: dict[str, Any]) -> datetime | None:
    """When the message arrived, from `internalDate` (milliseconds since 1970)."""
    try:
        return datetime.fromtimestamp(int(message["internalDate"]) / 1000, UTC)
    except (KeyError, TypeError, ValueError, OverflowError, OSError):
        return None


def _categories(label_ids: Any) -> tuple[str, ...]:
    """The message's Gmail tabs, from its `CATEGORY_<NAME>` labels: `<name>` in lower case, each once, as read."""
    found = [
        label[len("CATEGORY_") :].casefold()
        for label in (label_ids if isinstance(label_ids, list) else [])
        if isinstance(label, str) and label.startswith("CATEGORY_") and len(label) > len("CATEGORY_")
    ]
    return tuple(dict.fromkeys(found))


def message_item(message: dict[str, Any], chosen: dict[str, str], max_body_chars: int) -> SourceItem:
    """One Gmail message as a source item. `chosen` is the chosen labels, id -> the name the person gave."""
    payload = message.get("payload") if isinstance(message.get("payload"), dict) else {}
    headers = _headers(payload)
    subject = _decoded(headers.get("subject", ""))
    sender = _addresses(headers.get("from", ""))
    to, cc = _people(headers.get("to", "")), _people(headers.get("cc", ""))
    arrived = _moment(message)
    labels = ", ".join(name for label_id, name in chosen.items() if label_id in (message.get("labelIds") or []))
    attachments = _attachments(payload)
    head = [
        f"From: {_people(headers.get('from', ''))}" if sender else "",
        f"To: {to}" if to else "",
        f"Cc: {cc}" if cc else "",
        f"Date: {arrived:%Y-%m-%d %H:%M} UTC" if arrived else "",
        f"Subject: {subject}" if subject else "",
        f"Labels: {labels}" if labels else "",
        f"Attachments: {attachments}" if attachments else "",
        *sent_as(payload.get("headers")),
    ]
    body = _body(payload, max_body_chars)
    changed_at = arrived.isoformat(timespec="seconds").replace("+00:00", "Z") if arrived else None
    return SourceItem(
        key=str(message["id"]),
        title=subject or "(no subject)",
        text="\n".join(line for line in head if line) + (f"\n\n{body}" if body else ""),
        author=(sender[0][1] if sender else "") or None,
        changed_at=changed_at,
        link=f"https://mail.google.com/mail/#all/{message['id']}",
        # Opened or not is a detail only: it never goes in the text, or opening a message would hand it in again.
        message=MessageDetails(
            sender=_people(headers.get("from", "")) or None,
            received=changed_at,
            unread=UNREAD in (message.get("labelIds") or []),
            bulk=bulk(payload.get("headers")),
            categories=_categories(message.get("labelIds")),
        ),
    )


class _Queue:
    """The message ids waiting to be fetched, oldest first, each once."""

    def __init__(self, ids: Any):
        self.ids = list(dict.fromkeys(str(i) for i in ids if i)) if isinstance(ids, list) else []

    def add(self, new: list[str]) -> None:
        """Ids that came oldest first (history), after the ones waiting."""
        have = set(self.ids)
        self.ids += [i for i in dict.fromkeys(new) if i not in have]

    def add_listed(self, newest_first: list[str], *, older: bool) -> None:
        """Ids from a listing, which comes newest first. When this continues a listing that stopped part way, they
        are older than the ones already waiting from it, so they go in front."""
        have = set(self.ids)
        fresh = [i for i in reversed(list(dict.fromkeys(newest_first))) if i not in have]
        self.ids = fresh + self.ids if older else self.ids + fresh

    def discard(self, gone: Any) -> None:
        """Drop these ids from the waiting list."""
        gone = set(gone)
        if gone:
            self.ids = [i for i in self.ids if i not in gone]

    def take(self, count: int) -> list[str]:
        taken, self.ids = self.ids[:count], self.ids[count:]
        return taken

    def trim(self, most: int) -> None:
        """Keep the newest `most` ids."""
        self.ids = self.ids[-most:]


def _labels(reader: Reader, names: list[str], state: dict[str, Any]) -> tuple[dict[str, str], dict[str, str]]:
    """The chosen labels (id -> the name the person gave), and the name -> id list to remember."""
    if not names:
        return {}, {}
    body = reader.fetch(f"{GMAIL}/labels")
    listed = {
        str(label["id"]): (str(label.get("name") or ""), str(label["id"]))
        for label in body.get("labels") or []
        if isinstance(label, dict) and label.get("id")
    }
    remembered = state.get("labels") if isinstance(state.get("labels"), dict) else {}
    found: dict[str, str] = {}
    chosen: dict[str, str] = {}
    for name in names:
        key = name.casefold()
        label_id = find_by_name(name, listed, remembered.get(key))
        if not label_id:
            raise ConnectorError("not_found", f"No Gmail label named {name}")
        found[key] = label_id
        chosen.setdefault(label_id, name)
    return chosen, found


def _list(reader: Reader, query: str, queue: _Queue, listing: dict[str, Any], *, older: bool) -> bool:
    """Carry on a listing: for each label left in it (None is the whole mailbox), the ids of the messages after the
    time it names, page by page. `listing` is updated to where it stopped. Returns whether it is finished."""
    batch: list[str] = []
    finished = True
    while listing["labels"]:
        label = listing["labels"][0]
        params = {"q": f"({query}) after:{listing['after']}" if query else f"after:{listing['after']}"}
        params["maxResults"] = LIST_PAGE
        if label:
            params["labelIds"] = str(label)
        page = listing.get("page")
        while True:
            if reader.pages >= reader.max_pages:
                finished = False
                break
            body = reader.fetch(f"{GMAIL}/messages", {**params, "pageToken": str(page)} if page else params)
            batch += [str(m["id"]) for m in body.get("messages") or [] if isinstance(m, dict) and m.get("id")]
            page = listing["page"] = body.get("nextPageToken") or None
            if not page:
                break
        if not finished:
            break
        listing["labels"].pop(0)
        listing["page"] = None
    queue.add_listed(batch, older=older)
    return finished


def _record_ids(record: dict[str, Any], keys: tuple[str, ...]) -> list[tuple[str, set[str], set[str]]]:
    """The messages named by the entries of a history record under `keys`: each id with its labels at that time and
    the labels that entry added or removed."""
    found = []
    for key in keys:
        for entry in record.get(key) or []:
            message = entry.get("message") if isinstance(entry, dict) else None
            if isinstance(message, dict) and message.get("id"):
                changed = entry.get("labelIds")
                found.append(
                    (str(message["id"]), set(message.get("labelIds") or []), set(changed) if changed else set())
                )
    return found


def _history(
    reader: Reader,
    chosen: dict[str, str],
    queue: _Queue,
    removed: dict[str, None],
    start: str,
    page: str | None,
    unread_of: set[str] | None,
) -> dict[str, Any]:
    """Follow the mailbox's history from `start`. A message that was added, or newly labeled, with a chosen label
    waits to be fetched. A message that was deleted, or lost its last chosen label, is dropped from the waiting list
    and goes into `removed`. The records are in order, so a message added and then removed ends up removed (and one
    removed and then added again, added). With `unread_of`, a message under a chosen label whose only change was
    its unread mark waits to be fetched again too if `unread_of` (the ids fetched before) holds it. Any other change
    to an unread mark is left alone, and `unread_of` is None when tracking is off. Returns the state to keep:
    the next start, or the start and page token when the page cap stopped it part way."""
    params: dict[str, str | list[str]] = {
        "startHistoryId": start,
        "historyTypes": ["messageAdded", "labelAdded", "messageDeleted", "labelRemoved"],
        "maxResults": HISTORY_PAGE,
    }
    while True:
        if reader.pages >= reader.max_pages:
            return {"history": start, **({"history_page": page} if page else {})}
        body = reader.fetch(f"{GMAIL}/history", {**params, "pageToken": page} if page else params)
        added: dict[str, None] = {}
        dropped: dict[str, None] = {}
        for record in body.get("history") or []:
            if not isinstance(record, dict):
                continue
            for key in ("messagesAdded", "labelsAdded"):
                for message_id, labels, changed in _record_ids(record, (key,)):
                    unread_only = key == "labelsAdded" and changed == {UNREAD}
                    if not chosen.keys() & labels or (unread_only and message_id not in (unread_of or ())):
                        continue
                    added[message_id] = None
                    dropped.pop(message_id, None)
                    removed.pop(message_id, None)
            leaving = []
            for message_id, labels, changed in _record_ids(record, ("labelsRemoved",)):
                if not chosen.keys() & labels:  # the labels it still has hold none of the chosen ones
                    leaving.append(message_id)
                elif changed == {UNREAD} and message_id in (unread_of or ()):  # opened: the unread mark is behind
                    added[message_id] = None
                    dropped.pop(message_id, None)
                    removed.pop(message_id, None)
            for entry in record.get("messagesDeleted") or []:
                message = entry.get("message") if isinstance(entry, dict) else None
                if isinstance(message, dict) and message.get("id"):
                    leaving.append(str(message["id"]))
            for message_id in leaving:
                added.pop(message_id, None)
                dropped[message_id] = None
                removed[message_id] = None
        queue.discard(dropped)
        queue.add(list(added))
        page = body.get("nextPageToken") or None
        if not page:
            return {"history": str(body.get("historyId") or start)}


def _after(settings: MailSettings) -> int:
    """The first read's start: midnight UTC `days_back` days ago, in seconds since 1970."""
    return int(datetime.combine(_today() - timedelta(days=settings.days_back), time.min, UTC).timestamp())


def _by_labels(
    reader: Reader,
    settings: MailSettings,
    chosen: dict[str, str],
    queue: _Queue,
    removed: dict[str, None],
    mine: dict[str, Any],
    unread_of: set[str] | None,
) -> dict[str, Any]:
    """Label mode. Returns the tracking state to keep; the ids that are gone are added to `removed`."""
    listing = mine.get("listing") if isinstance(mine.get("listing"), dict) else None
    if not listing and mine.get("history"):
        try:
            return _history(reader, chosen, queue, removed, str(mine["history"]), mine.get("history_page"), unread_of)
        except ConnectorError as err:
            # Gmail answers 404 (body: status NOT_FOUND, reason notFound) when the start is too old, and the web
            # client raises not_found for any 404. The labels were just looked up, so this one is the history: read
            # from scratch. It is only tried once per read: the listing below may raise not_found too, and that
            # goes on up.
            if err.kind != "not_found":
                raise
    resumed = listing is not None
    if listing is None:
        # Take the mailbox's place in its history before listing, so nothing that arrives meanwhile is missed.
        profile = reader.fetch(f"{GMAIL}/profile", counted=False)
        if not profile.get("historyId"):
            raise ConnectorError("outage", "Google: the mailbox profile had no history id")
        listing = {
            "after": _after(settings),
            "labels": list(chosen),
            "page": None,
            "history": str(profile["historyId"]),
        }
    else:
        listing = {**listing, "labels": list(listing.get("labels") or [])}
    if _list(reader, "", queue, listing, older=resumed):
        return {"history": listing["history"]}
    return {"listing": listing}


def _by_search(
    reader: Reader, settings: MailSettings, chosen: dict[str, str], queue: _Queue, mine: dict[str, Any]
) -> tuple[dict[str, Any], int]:
    """Search mode. Returns the tracking state to keep (when the last finished listing started, and any listing
    that stopped part way) and the start of the overlap this read looks back to, in seconds since 1970."""
    listing = mine.get("listing") if isinstance(mine.get("listing"), dict) else None
    last = None
    with contextlib.suppress(ValueError):
        last = datetime.fromisoformat(str(mine["read_at"])) if mine.get("read_at") else None
    resumed = listing is not None
    if listing is not None:
        listing = {**listing, "labels": list(listing.get("labels") or [])}
    else:
        started = _now()
        since = (
            _after(settings)
            if last is None
            else int((last - timedelta(minutes=settings.search_overlap_minutes)).timestamp())
        )
        listing = {
            "after": max(since, 0),
            "labels": list(chosen) or [None],
            "page": None,
            "started": started.isoformat(),
        }
    if _list(reader, settings.query.strip(), queue, listing, older=resumed):
        return {"read_at": listing["started"]}, int(listing["after"])
    return {"listing": listing, **({"read_at": mine["read_at"]} if last else {})}, int(listing["after"])


def _fetch(
    reader: Reader, settings: MailSettings, chosen: dict[str, str], queue: _Queue
) -> tuple[list[SourceItem], dict[str, int]]:
    """Fetch the next waiting messages, oldest first. One that went in the meantime is skipped. Returns the items
    and, for each message fetched, when it arrived (milliseconds since 1970)."""
    items = []
    fetched: dict[str, int] = {}
    for message_id in queue.take(settings.max_messages_per_read):
        try:
            message = reader.fetch(f"{GMAIL}/messages/{quote(message_id, safe='')}", {"format": "full"}, counted=False)
        except ConnectorError as err:
            if err.kind != "not_found":
                raise
            continue
        message.setdefault("id", message_id)
        items.append(message_item(message, chosen, settings.max_body_chars))
        arrived = _moment(message) or _now()
        fetched[str(message["id"])] = int(arrived.timestamp() * 1000)
    return items, fetched


def _remembered(before: Any, fetched: dict[str, int], since: int, most: int) -> dict[str, int]:
    """The messages fetched in search mode that a later listing could bring up again: those that arrived at or after
    the start of the overlap (`since`, seconds), the newest `most` of them."""
    found = {**(before if isinstance(before, dict) else {}), **fetched}
    recent = [(i, ms) for i, ms in found.items() if isinstance(ms, int) and ms >= since * 1000]
    return dict(sorted(recent, key=lambda found_at: found_at[1])[-most:])


def read_mail(settings: MailSettings, state: dict[str, Any], context: Any) -> Poll:
    """Read the messages under the chosen labels (or matching the search). Returns what was fetched this time and,
    in label mode, what is gone; `state` keeps where the reading stands and the ids that wait."""
    names = list(dict.fromkeys(name.strip() for name in settings.labels if name.strip()))
    query = settings.query.strip()
    if not names and not query:
        names = [INBOX]  # no choice made: the inbox, exactly as if it were named
    reader = Reader(
        context,
        max_pages=settings.max_pages_per_read,
        max_items=settings.max_messages_per_read,
        throttle_wait=settings.throttle_wait_seconds,
        api_off=MAIL_API_OFF,
    )
    require_scope(context, SIGN_IN, MAIL_SCOPE, MAIL_NOT_ALLOWED)
    chosen, remembered = _labels(reader, names, state)
    if names and reader.pages >= settings.max_pages_per_read:
        raise ConnectorError(
            "outage", "Google: the page limit for one read is used up by the label lookup; raise max_pages_per_read"
        )
    scope = {"labels": sorted(chosen), "query": query}
    mine = state if state.get("scope") == scope else {}  # other labels or another search start afresh
    queue = _Queue(mine.get("waiting"))
    removed: dict[str, None] = {}
    extra: dict[str, Any] = {}
    known: list[str] = []
    if query:
        tracking, since = _by_search(reader, settings, chosen, queue, mine)
        queue.discard(mine.get("fetched") or [])  # fetched in the overlap of an earlier read: not again
    else:
        before = mine.get("known") if isinstance(mine.get("known"), list) else []
        known = [str(i) for i in before if i]
        tracking = _by_labels(
            reader, settings, chosen, queue, removed, mine, set(known) if settings.track_unread else None
        )
    items, fetched = _fetch(reader, settings, chosen, queue)
    if query:
        extra["fetched"] = _remembered(mine.get("fetched"), fetched, since, settings.max_waiting)
    queue.trim(settings.max_waiting)
    new_state = {"scope": scope, "labels": remembered, "waiting": queue.ids, **tracking, **extra}
    taken = {item.key for item in items}
    gone = [key for key in removed if key not in taken]
    if not query:
        # The messages read in so far, newest last: only these have an unread mark Today could be showing.
        again = taken | set(gone)
        new_state["known"] = ([i for i in known if i not in again] + [item.key for item in items])[
            -settings.max_waiting :
        ]
    return Poll(items=items, state=new_state, complete=False, removed=gone)
