"""What the Google connectors share: a bounded reader of Google API feeds, with the token and headers, paging by
`pageToken`, the page and item caps, resume, the once-per-read restart of an expired sync token, and name matching
against a listed collection. The calendar and mail connectors keep only what is their own."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from datetime import date
from typing import Any

from engine.plugin_api import ConnectorError, SourceItem, retry_after

from cockpit_mail_calendar_common import service_error

SIGN_IN = "google/account"
CALENDAR = "https://www.googleapis.com/calendar/v3"
GMAIL = "https://gmail.googleapis.com/gmail/v1/users/me"
#: A query: a value is one string, or a list of strings for a name that is repeated (`historyTypes=a&historyTypes=b`).
Params = Mapping[str, str | list[str]]
#: The reasons Google gives with a 403 when it means "too many requests", not "no access".
RATE_LIMITS = {"rateLimitExceeded", "userRateLimitExceeded"}
#: The `@type` of the error detail whose `reason` says a service is disabled.
ERROR_INFO = "type.googleapis.com/google.rpc.ErrorInfo"


def _reason(err: ConnectorError) -> str | None:
    """The first reason in the error body of an answer the web client raised on (Google's `error.errors[0].reason`)."""
    body = err.json()
    error = body.get("error") if isinstance(body, dict) else None
    details = error.get("errors") if isinstance(error, dict) else None
    first = details[0] if isinstance(details, list) and details else None
    reason = first.get("reason") if isinstance(first, dict) else None
    return reason if isinstance(reason, str) else None


def _api_turned_off(err: ConnectorError) -> bool:
    """Whether a 403 says the API is turned off in the app registration's project: an `accessNotConfigured` reason in
    `error.errors`, or a `SERVICE_DISABLED` reason in an `ErrorInfo` entry of `error.details`. Codes only."""
    body = err.json()
    error = body.get("error") if isinstance(body, dict) else None
    if not isinstance(error, dict):
        return False
    errors, details = error.get("errors"), error.get("details")
    if isinstance(errors, list) and any(
        isinstance(e, dict) and e.get("reason") == "accessNotConfigured" for e in errors
    ):
        return True
    return isinstance(details, list) and any(
        isinstance(d, dict) and d.get("@type") == ERROR_INFO and d.get("reason") == "SERVICE_DISABLED" for d in details
    )


def stamp(day: date) -> str:
    """The start of a day in UTC, as Google takes it in a query."""
    return f"{day.isoformat()}T00:00:00Z"


def person(who: Any) -> str:
    """A Google `organizer` or `attendee` as `Name <address>`, or whichever of the two there is."""
    who = who if isinstance(who, dict) else {}
    name, email = str(who.get("displayName") or ""), str(who.get("email") or "")
    if name and email and name != email:
        return f"{name} <{email}>"
    return email or name


def find_by_name(name: str, listed: dict[str, tuple[str, ...]], remembered_id: str | None = None) -> str | None:
    """The id of the entry that goes by `name` (ignoring case) in `listed` (id -> the names it goes by, best first).
    When no entry goes by that name, the remembered id is kept if it is still listed, so a renamed entry is still
    read."""
    by_name: dict[str, str] = {}
    for rank in range(max((len(names) for names in listed.values()), default=0)):
        for item_id, names in listed.items():
            if rank < len(names) and names[rank]:
                by_name.setdefault(names[rank].casefold(), item_id)
    found = by_name.get(name.casefold())
    return found or (remembered_id if remembered_id in listed else None)


class Feed:
    """One place to read. `base` is the query every request of it has; `full` is the first request of a full read
    (the base plus whatever narrows it, such as a window). A read from a sync token is the base plus the token."""

    def __init__(self, key: str, url: str, *, base: dict[str, str], full: dict[str, str] | None = None):
        self.key, self.url, self.base, self.full = key, url, base, full if full is not None else base


class Reader:
    """One read: the requests it made, the items it took, and where it stopped.

    `convert` turns a Google entry into an item; `skip` says which entries to leave out (entries without an id are
    always left out). A page is taken whole or left for the next read. A connector that doesn't read feeds (Gmail
    lists ids and fetches each message itself) leaves `convert` out and uses only `fetch`. `api_off` is the words for
    this connector's API being turned off in the app registration's project, used for the 403 that says so.
    """

    def __init__(
        self,
        context: Any,
        *,
        max_pages: int,
        max_items: int,
        throttle_wait: int = 60,
        convert: Callable[[dict[str, Any], Feed], SourceItem] | None = None,
        skip: Callable[[dict[str, Any]], bool] | None = None,
        api_off: str | None = None,
    ):
        token = context.access_token(SIGN_IN)  # a withdrawn sign-in raises auth, which propagates
        self.web = context.web
        self.headers = {"Authorization": f"Bearer {token}"}
        self.max_pages, self.max_items = max_pages, max_items
        self.throttle_wait = throttle_wait
        self.convert, self.skip = convert, skip
        self.api_off = api_off
        self.items: dict[str, SourceItem] = {}
        self.pages = 0
        self.restarted = False

    @property
    def full(self) -> bool:
        """Whether this read has used its pages or filled its items."""
        return self.pages >= self.max_pages or len(self.items) >= self.max_items

    def get(self, url: str, params: Params | None = None) -> tuple[int, Any]:
        """One GET, not counted. Returns the status and the decoded body (None when it isn't JSON). A 403 that
        Google gives for too many requests is throttling: it raises `throttled`, waiting as long as Google's
        Retry-After says, or else `throttle_wait` seconds. A 403 that says the API is turned off in the registration's
        project is `no_access` with the `api_off` words (when there are any)."""
        try:
            response = self.web.get(url, params=params, headers=self.headers)
        except ConnectorError as err:
            if err.kind == "no_access" and err.status == 403 and _reason(err) in RATE_LIMITS:
                wait = retry_after(err.headers)
                raise ConnectorError(
                    "throttled",
                    "Google: the service asked to wait (too many requests)",
                    retry_after=self.throttle_wait if wait is None else wait,
                    status=err.status,
                    headers=err.headers,
                    body=err.body,
                ) from None
            if err.kind == "no_access" and err.status == 403 and self.api_off and _api_turned_off(err):
                raise ConnectorError(
                    "no_access", self.api_off, status=err.status, headers=err.headers, body=err.body
                ) from None
            raise
        try:
            body = response.json()
        except ValueError:
            body = None
        return response.status, body

    def fetch(self, url: str, params: Params | None = None, *, counted: bool = True) -> dict[str, Any]:
        """One GET that must succeed with a JSON object. A counted request is one of this read's pages."""
        if counted:
            if self.pages >= self.max_pages:
                raise ConnectorError(
                    "outage", "Google: the page limit for one read ran out before the lookups were done"
                )
            self.pages += 1
        status, body = self.get(url, params)
        if status >= 300:
            raise service_error(status, body, "Google")
        if not isinstance(body, dict):
            raise ConnectorError("outage", "Google: the answer wasn't readable")
        return body

    def listing(self, url: str, params: dict[str, str], *, counted: bool) -> list[dict[str, Any]]:
        """Every entry of a collection, following `nextPageToken`, in at most `max_pages` requests."""
        entries: list[dict[str, Any]] = []
        page = None
        for _ in range(self.max_pages):
            body = self.fetch(url, {**params, "pageToken": page} if page else params, counted=counted)
            entries.extend(entry for entry in body.get("items", []) if isinstance(entry, dict))
            page = body.get("nextPageToken")
            if not page:
                break
        return entries

    def read_feed(self, feed: Feed, saved: dict[str, Any]) -> tuple[dict[str, Any], bool]:
        """Read one feed from its saved state. Returns the state to keep for it and whether it was finished.

        The state is `{"sync": token}` after a finished read, `{"query": {...}, "page": token}` part way through a
        chain of pages (every page repeats the first request's query), and `{}` when the next read starts afresh.
        """
        if saved.get("page") and isinstance(saved.get("query"), dict):
            query, page = dict(saved["query"]), str(saved["page"])
        elif saved.get("sync"):
            query, page = {**feed.base, "syncToken": str(saved["sync"])}, None
        else:
            saved, query, page = {}, feed.full, None
        while True:
            if self.pages >= self.max_pages:
                return ({"query": query, "page": page} if page else saved), False
            self.pages += 1
            status, body = self.get(feed.url, {**query, "pageToken": page} if page else query)
            if status == 410 and not self.restarted and (page or "syncToken" in query):
                # The sync token (or a page token) expired: start this feed again, once per read.
                self.restarted = True
                saved, query, page = {}, feed.full, None
                continue
            if status >= 300:
                raise service_error(status, body, "Google")
            if not isinstance(body, dict):
                raise ConnectorError("outage", "Google: the answer wasn't readable")
            entries = [e for e in body.get("items", []) if e.get("id") and not (self.skip and self.skip(e))]
            if self.items and len(self.items.keys() | {str(e["id"]) for e in entries}) > self.max_items:
                return ({"query": query, "page": page} if page else saved), False  # this page waits for next time
            for entry in entries:
                if self.convert is None:
                    raise TypeError("this reader has no convert, so it can't read feeds")
                item = self.convert(entry, feed)
                self.items[item.key] = item
            if body.get("nextPageToken"):
                page = str(body["nextPageToken"])
                if len(self.items) >= self.max_items:
                    return {"query": query, "page": page}, False
            elif body.get("nextSyncToken"):
                return {"sync": str(body["nextSyncToken"])}, True
            else:
                return {}, True
