# Google: Gmail and Google Calendar

## Signing in

You sign in to Google on Google's own page, so PM Cockpit never sees your password. There is nothing to register
first: the add-on comes with the publisher's app registration.

1. Open Add-ons and turn the add-on on.
2. Open Settings, then Sign-ins, and choose Sign in next to Google.
3. PM Cockpit lists what you will be asked to allow. Then you go to Google's page: check the account and the list,
   and allow it.

When you come back, the row shows which account is signed in.

While the publisher's app is in testing, only people the publisher has added as testers can sign in. Google shows a
page saying the app isn't verified: choose Continue. And Google ends the sign-in after 7 days, so you will be asked to
sign in again every week.

### Using your own app registration

You can use an app registration of your own instead. It avoids the publisher's testing limits, and it suits an
organization that wants its own. On the Google row under Settings, Sign-ins, paste your client ID and client secret,
following the steps listed there. They make a project in Google Cloud, turn on the Gmail and Google Calendar APIs,
set up the consent screen and create a client of type Desktop app. When your account belongs to a Google Workspace
organization (a company or school address), choose Internal for the consent screen: it has no testers list and no
7-day limit. Otherwise choose External and add your own address as a test user. An External app stays in Testing, so
you sign in again every week; taking an app that reads Gmail out of Testing needs Google's security review.

## What it can read and what it can't

PM Cockpit shows you these lines before you sign in:

- Read your Gmail (it can't send, delete or change anything)
- Read your Google Calendar (it can't add or change events)
- Stay signed in, so it can keep reading while you're away

It only reads. It never sends mail, deletes anything, marks mail read, moves or labels mail, or adds or changes
events. It asks Google for read permissions only. Google's page may let you turn one of them off. If you do, the
Sign-ins row names the one that wasn't allowed, and reading that part stops with a message to sign in again.

The calendar fills Today's agenda, and mail fills what came in today. Whether a message has been opened or is unread
is shown there, but it is never treated as a change for the assistant.

Signing in reads your whole inbox. PM Cockpit sets aside mailing-list and bulk mail, and mail in Gmail's Promotions,
Social and Forums tabs, in its Set aside folder without spending an AI run on it. You can see it there and mark a
message as work.

## Choosing what to read

Signing in starts reading your inbox and your calendar, every 15 minutes. You can narrow, add or remove sources on PM
Cockpit's sources screen or in `config/watch.yaml`. A mail source with no labels and no search reads your inbox. Once
you name labels or a search, it reads only what you choose. There are two modes:

- Labels: PM Cockpit follows changes to the labels you name. New mail with one of them is read. Mail that is deleted,
  or loses all the chosen labels, is reported as gone.
- Search: each read lists the messages that match your Gmail search and arrived since the last read, looking back a
  little to catch late arrivals. It can't tell when a message stops matching, so it reports nothing as gone.

With both, a message must have one of the labels and match the search. Calendar is different: with no `calendars`
named, it reads your primary calendar. Events are read in a window around today (`days_back`, `days_ahead`).

By default the first read of a source only notes what is there, and later reads hand in what is new or changed. Set
`first_run: all` on the source to hand in everything on the first read. Example `config/watch.yaml` sources:

```yaml
sources:
  - id: alpha-mail
    connector: google/mail
    label: Alpha project mail
    every_minutes: 30
    settings:
      labels: [Projects/Alpha]
  - id: invoices
    connector: google/mail
    label: Invoices
    settings:
      query: "from:billing.example.com has:attachment"
      days_back: 30
  - id: team-calendar
    connector: google/calendar
    label: Team calendar
    settings:
      calendars: [Team planning]
      days_ahead: 30
```

## When it asks you to sign in again

PM Cockpit asks once, and shows Sign in again on the row, when:

- Google refuses to renew your sign-in.
- You withdrew the access at Google (see "Withdrawing access").
- A permission wasn't allowed when you signed in. The message says "Reading mail wasn't allowed when you signed in.
  Sign in again and allow it." (or the same for your calendar).
- You use the publisher's app registration, or your own External app in Testing, and 7 days have passed since you
  signed in. Google ends a Testing app's sign-ins after 7 days.

To fix it, open Settings, Sign-ins, choose Sign in again, and allow everything on Google's page. The question closes
by itself once you are signed in.

## Withdrawing access

Signing out in Settings, Sign-ins, forgets the sign-in on this computer. It also asks Google to withdraw the access.
That is best effort: if Google can't be reached, do it yourself. Go to <https://myaccount.google.com/permissions>,
choose the app, then choose Delete all connections.

## Limits and waiting

Each limit is a setting on the source, and every one has a default.

Mail:

- `days_back` (14): how far back the first read goes.
- `max_messages_per_read` (100): the most messages one read takes. The rest wait for the next read.
- `max_pages_per_read` (20): the most list, history and label pages one read asks Google for.
- `max_waiting` (5000): the most message ids kept waiting between reads. Past this, the oldest are dropped.
- `search_overlap_minutes` (60): with a search, how far before the last read each read looks again.
- `max_body_chars` (8000): how much of a message's text is kept.
- `track_unread` (on): keep Today's unread marks current when you open a message or mark it unread. It costs one
  request per message, and only for messages already read in. It works with labels only, not with a search.

Calendar:

- `days_back` (7) and `days_ahead` (60): the window of events.
- `max_events_per_read` (500) and `max_pages_per_read` (20): the most events and pages one read takes.
- `max_description_chars` (4000): how much of an event's description is kept.

When Google says "please wait" (too many requests), PM Cockpit waits as long as Google asks and doesn't count it as a
failure. When Google doesn't say how long, it waits `throttle_wait_seconds` (60). It never retries in a loop.

## Filtering mailing lists and automatic replies

Three rule kinds close a change before the assistant reads it. You can see what they closed, and why, under
Auto-closed, and take a closer look at any of it.

- `google/mailing-lists` closes new or changed mail sent to a mailing list. The optional `keep_from` lists addresses
  or `@domain`s whose list mail you still want.
- `google/automatic-replies` closes new or changed mail that is an automatic reply, such as an out-of-office note.
- `google/answers-only` closes a changed event when only attendees' answers changed. It leaves alone an event where
  someone was added or removed.

Mail is marked from its own headers, never from the subject or the text. A message gets the line "Sent as: mailing
list" or "Sent as: automatic reply" when its headers say so, and the rules read that line. Example in `config/watch.yaml`:

```yaml
triage:
  - name: Skip mailing lists
    kind: google/mailing-lists
    params:
      keep_from: ["lead@example.com", "@client.example.com"]
    sources: [alpha-mail]
  - name: Skip automatic replies
    kind: google/automatic-replies
  - name: Skip answers to invitations
    kind: google/answers-only
    sources: [team-calendar]
```

## Acting after your yes

The assistant only drafts. Each message, filing change or calendar change goes out only after your yes on that exact
one.

- Turning on acting for an account sends you to Google's page once more, to allow sending and changing mail and
  events. While the publisher's app is in testing, Google shows its page saying the app isn't verified again
  (choose Continue).
- You can take back a filing change, a read mark and an event you created. You can't take back a sent message, a moved
  or cancelled event, or an answer to an invitation.
- Nothing is ever deleted or put in the bin.
- Turning acting off stops it at once.
