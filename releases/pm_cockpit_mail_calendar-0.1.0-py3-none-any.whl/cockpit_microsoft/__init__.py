"""Reads a person's Outlook mail and calendar through Microsoft Graph, signed in as the person. Read-only."""

import re
from pathlib import Path

from engine.plugin_api import Registrar, Settings
from pydantic import Field, field_validator

from cockpit_mail_calendar_common import shipped_app
from cockpit_mail_calendar_common.triage import answers_only, automatic_replies, mailing_lists

from .calendar import CalendarSettings, read_calendar
from .mail import MailSettings, read_mail
from .sign_in import ALLOWS, DEFAULT_APP_NOTE, DEFAULT_REDIRECTS, OWN_APP_STEPS, SCOPES, SOURCES, account

_TENANT = re.compile(r"[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?")


class Config(Settings):
    tenant: str = Field(
        "common",
        description=(
            "Which Microsoft accounts can sign in: 'common' for work, school and personal accounts, 'organizations' "
            "for work and school only, 'consumers' for personal only, or one organization's tenant id or domain."
        ),
    )

    @field_validator("tenant")
    @classmethod
    def _tenant(cls, value: str) -> str:
        """Checked with the settings, so the Settings screen refuses a bad value on save, naming the field."""
        return _check_tenant(value)


def _check_tenant(tenant: str) -> str:
    """'common', 'organizations', 'consumers', a tenant id (GUID) or a domain name; nothing else goes in an address."""
    if not _TENANT.fullmatch(tenant) or ".." in tenant:
        raise ValueError(
            f"tenant {tenant[:60]!r} isn't valid: use 'common', 'organizations', 'consumers', a tenant id (a GUID) "
            "or a domain name such as example.com"
        )
    return tenant


def register(registrar: Registrar) -> None:
    """Register the Microsoft sign-in (with the publisher's app registration, when the package ships one), the
    calendar and mail connectors and the triage rule kinds."""
    tenant = registrar.config.tenant  # already checked by Config
    login = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0"
    app = shipped_app(Path(__file__).parent)
    registrar.sign_in(
        "microsoft/account",
        label="Microsoft account",
        authorize_url=f"{login}/authorize",
        token_url=f"{login}/token",
        scopes=SCOPES,
        client_id="client-id",
        params={"prompt": "select_account"},
        allows=ALLOWS,
        account=account,
        default_client_id=app.get("client_id"),
        default_app_note=DEFAULT_APP_NOTE,
        default_redirects=DEFAULT_REDIRECTS if app.get("client_id") else (),
        own_app_steps=OWN_APP_STEPS,
        sources=SOURCES,
    )
    registrar.connector(
        "microsoft/calendar", label="Outlook calendar", settings=CalendarSettings, poll=read_calendar, reads="calendar"
    )
    registrar.connector("microsoft/mail", label="Outlook mail", settings=MailSettings, poll=read_mail, reads="mail")
    registrar.triage_matcher("microsoft/mailing-lists", match=mailing_lists)
    registrar.triage_matcher("microsoft/automatic-replies", match=automatic_replies)
    registrar.triage_matcher("microsoft/answers-only", match=answers_only)
