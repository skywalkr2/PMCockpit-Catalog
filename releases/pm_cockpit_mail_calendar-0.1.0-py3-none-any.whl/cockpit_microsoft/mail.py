"""The Outlook mail connector: messages in the folders the person names, read through Microsoft Graph. Read-only.

With no folder named, it reads the well-known inbox. Each folder is read with a message delta: the first read takes
the last `days_back` days, and later reads take only what changed. Messages the delta says are gone (deleted, or
moved out of the folder) are handed in as removed. A read is bounded by pages and messages; what it didn't reach
waits in `state` for the next read. Only GET requests are made.
"""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta
from typing import Any
from urllib.parse import quote

from engine.plugin_api import ConnectorError, MessageDetails, Poll, SourceItem
from pydantic import BaseModel, ConfigDict, Field

from cockpit_mail_calendar_common import require_scope
from cockpit_mail_calendar_common.triage import bulk, sent_as

from .graph import GRAPH, PAGE_SIZE, SIGN_IN, Feed, Reader, body_text, find_by_name, person, stamp
from .sign_in import MAIL_NOT_ALLOWED, MAIL_SCOPE

PREFER = f'odata.maxpagesize={PAGE_SIZE}, outlook.body-content-type="text", IdType="ImmutableId"'
FOLDERS = f"{GRAPH}/me/mailFolders"
WELL_KNOWN = {"inbox", "archive", "sentitems", "drafts", "deleteditems", "junkemail"}
_FOLDER_QUERY = {"$select": "id,displayName", "$top": "100"}
_SELECT = (
    "id,subject,from,toRecipients,ccRecipients,receivedDateTime,lastModifiedDateTime,"
    "hasAttachments,body,webLink,isDraft,isRead,internetMessageHeaders,categories,inferenceClassification"
)


class MailSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    folders: list[str] = Field(
        default_factory=list,
        description=(
            "The folders to read: a well-known name (inbox, archive, sentitems), a folder's name, or a path "
            "such as Inbox/Projects. Empty means your inbox."
        ),
    )
    days_back: int = Field(
        14, ge=0, le=365, description="How many days back the first read goes. Later reads take only what changed."
    )
    max_messages_per_read: int = Field(
        200, ge=1, le=5000, description="The most messages one read hands in. The rest wait for the next read."
    )
    max_pages_per_read: int = Field(
        20,
        ge=1,
        le=200,
        description="The most pages one read asks the service for, folder lookups included. The rest wait.",
    )
    max_body_chars: int = Field(
        8000, ge=0, le=100000, description="How much of a message's text is kept. 0 keeps none."
    )
    attachment_names: bool = Field(
        True,
        description="Whether to list attachment names. This costs one request for each message with attachments.",
    )
    max_attachment_lookups_per_read: int = Field(
        50,
        ge=0,
        le=1000,
        description="The most messages per read whose attachment names are looked up. The rest say names weren't read.",
    )


def _today() -> date:
    return datetime.now(UTC).date()


def _received(value: Any) -> str:
    """A Graph UTC time such as 2026-10-12T09:14:00Z as `2026-10-12 09:14 UTC`, or "" when it isn't one."""
    try:
        moment = datetime.fromisoformat(str(value))
    except ValueError:
        return ""
    moment = moment.replace(tzinfo=UTC) if moment.tzinfo is None else moment.astimezone(UTC)
    return f"{moment:%Y-%m-%d %H:%M} UTC"


def _received_at(value: Any) -> str | None:
    """A Graph UTC time as ISO 8601 with `Z`, or None when it isn't one."""
    try:
        moment = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    moment = moment.replace(tzinfo=UTC) if moment.tzinfo is None else moment.astimezone(UTC)
    return f"{moment:%Y-%m-%dT%H:%M:%S}Z"


def _people(recipients: Any) -> str:
    return ", ".join(name for name in (person(r.get("emailAddress")) for r in recipients or []) if name)


class _Messages:
    """Turns messages into items. Looking up attachment names makes requests, so it shares the read's page count."""

    def __init__(self, settings: MailSettings):
        self.settings = settings
        self.reader: Reader | None = None  # set once the read exists
        self.lookups = 0

    def attachments(self, message: dict[str, Any]) -> str:
        """The attachment names, "yes (names not read)" when they weren't looked up, or "" when there are none."""
        if not message.get("hasAttachments"):
            return ""
        settings, reader = self.settings, self.reader
        if (
            reader
            and settings.attachment_names
            and self.lookups < settings.max_attachment_lookups_per_read
            and reader.pages < reader.max_pages
        ):
            self.lookups += 1
            try:
                body = reader.fetch(
                    f"{GRAPH}/me/messages/{quote(str(message['id']), safe='')}/attachments",
                    {"$select": "name,isInline"},
                )
            except ConnectorError as err:
                if err.kind != "not_found":  # the message moved or went since its page: say names weren't read
                    raise
            else:
                names = [str(a.get("name") or "").strip() for a in body.get("value", []) if not a.get("isInline")]
                return ", ".join(name for name in names if name)
        return "yes (names not read)"

    def item(self, message: dict[str, Any], feed: Feed) -> SourceItem:
        """One Graph message as a source item."""
        subject = str(message.get("subject") or "").strip()
        sender = (message.get("from") or {}).get("emailAddress")
        sent = person(sender)
        to, cc = _people(message.get("toRecipients")), _people(message.get("ccRecipients"))
        date_ = _received(message.get("receivedDateTime"))
        attachments = self.attachments(message)
        head = [
            f"From: {sent}" if sent else "",
            f"To: {to}" if to else "",
            f"Cc: {cc}" if cc else "",
            f"Date: {date_}" if date_ else "",
            f"Subject: {subject}" if subject else "",
            f"Folder: {feed.label}" if feed.label else "",
            f"Attachments: {attachments}" if attachments else "",
            *sent_as(message.get("internetMessageHeaders")),
        ]
        body = body_text(message.get("body"), self.settings.max_body_chars)
        return SourceItem(
            key=str(message["id"]),
            title=subject or "(no subject)",
            text="\n".join(line for line in head if line) + (f"\n\n{body}" if body else ""),
            author=((sender or {}).get("address") if isinstance(sender, dict) else None) or None,
            changed_at=message.get("lastModifiedDateTime"),
            link=message.get("webLink"),
            # Opened or not is a detail only: it never goes in the text, or opening a message would hand it in again.
            message=MessageDetails(
                sender=sent or None,
                received=_received_at(message.get("receivedDateTime")),
                unread=None if "isRead" not in message else not message["isRead"],
                bulk=bulk(message.get("internetMessageHeaders")),
                categories=_categories(message),
            ),
        )


def _categories(message: dict[str, Any]) -> tuple[str, ...]:
    """The message's own categories, then Focused or Other when Graph says: trimmed, in lower case, each once."""
    own = message.get("categories")
    found = [str(name).strip().casefold() for name in (own if isinstance(own, list) else [])]
    found.append(str(message.get("inferenceClassification") or "").strip().casefold())
    return tuple(dict.fromkeys(name for name in found if name))


def _folder_by_id(reader: Reader, folder: str) -> str | None:
    """The id of the folder at `/me/mailFolders/{folder}` (a well-known name or an id), None when it isn't there."""
    try:
        body = reader.fetch(f"{FOLDERS}/{quote(folder, safe='')}", {"$select": "id,displayName"})
    except ConnectorError as err:
        if err.status == 404:  # the web client raises not_found on a 404 and keeps the status
            return None
        raise
    return str(body["id"]) if body.get("id") else None


def _folder_id(reader: Reader, name: str, remembered_id: str | None) -> str | None:
    """The id of the folder the person named: a well-known name, the remembered id if it still answers, or the
    path of display names walked down from the top. None when none of them leads to a folder."""
    parts = [part.strip() for part in name.split("/") if part.strip()]
    if len(parts) == 1 and parts[0].casefold() in WELL_KNOWN:
        return _folder_by_id(reader, parts[0].casefold())
    if remembered_id and _folder_by_id(reader, remembered_id):
        return remembered_id  # still there, maybe under another name
    parent = None
    for part in parts:
        url = FOLDERS if parent is None else f"{FOLDERS}/{quote(parent, safe='')}/childFolders"
        listed = {
            str(f["id"]): str(f.get("displayName") or "")
            for f in reader.listing(url, dict(_FOLDER_QUERY), counted=True)
            if f.get("id")
        }
        parent = find_by_name(part, listed)
        if parent is None:
            return None
    return parent


def _feeds(reader: Reader, names: list[str], since: str, state: dict[str, Any]) -> tuple[list[Feed], dict[str, str]]:
    """The folders to read, and the name -> id list to remember."""
    remembered = state.get("folders") or {}
    saved = state.get("feeds") or {}
    found: dict[str, str] = {}
    feeds: dict[str, Feed] = {}
    for name in names:
        key = name.casefold()
        known = remembered.get(key)
        if known and (saved.get(known) or {}).get("next"):
            folder_id: str | None = known  # part way through a folder: carry on from the saved link
        else:
            folder_id = _folder_id(reader, name, known)
        if not folder_id:
            raise ConnectorError("not_found", f"No mail folder named {name}")
        found[key] = folder_id
        feeds.setdefault(
            folder_id,
            Feed(
                folder_id,
                f"{FOLDERS}/{quote(folder_id, safe='')}/messages/delta",
                delta=True,
                params={"$select": _SELECT, "$filter": f"receivedDateTime ge {since}"},
                label=name,
            ),
        )
    return list(feeds.values()), found


def read_mail(settings: MailSettings, state: dict[str, Any], context: Any) -> Poll:
    """Read the messages in the named folders. Returns what was taken this time; `state` keeps where each stands."""
    names = [name.strip() for name in settings.folders if name.strip()]
    if not names:
        names = ["inbox"]  # no choice made: the well-known inbox, exactly as if it were named
    messages = _Messages(settings)
    reader = Reader(
        context,
        prefer=PREFER,
        max_pages=settings.max_pages_per_read,
        max_items=settings.max_messages_per_read,
        convert=messages.item,
        skip=lambda message: bool(message.get("isDraft")),
    )
    messages.reader = reader
    require_scope(context, SIGN_IN, MAIL_SCOPE, MAIL_NOT_ALLOWED)
    since = stamp(_today() - timedelta(days=settings.days_back))
    feeds, remembered = _feeds(reader, names, since, state)
    if reader.pages >= settings.max_pages_per_read:
        raise ConnectorError(
            "outage", "Microsoft: the page limit for one read is used up by folder lookups; raise max_pages_per_read"
        )
    saved = state.get("feeds") or {}
    start = next((i for i, feed in enumerate(feeds) if feed.key == state.get("resume")), 0)
    keep = {feed.key: saved.get(feed.key, {}) for feed in feeds}
    stopped = None
    for feed in feeds[start:] + feeds[:start]:
        if reader.full:
            stopped = stopped or feed.key
            break
        keep[feed.key], finished = reader.read_feed(feed, keep[feed.key])
        if not finished:
            stopped = feed.key
            break
    new_state = {"folders": remembered, "feeds": keep, "resume": stopped}
    return Poll(items=list(reader.items.values()), state=new_state, complete=False, removed=list(reader.removed))
