"""The Outlook calendar connector: events in a window around today, read through Microsoft Graph. Read-only.

The default calendar is read with a delta (only what changed since the last read), and the events the delta says
are gone are handed in as removed. Named calendars are read as a complete listing of the window each time, because
the per-calendar delta address isn't confirmed for Graph v1.0 (see `_feeds`); what the last finished listing had and
the new one lacks is handed in as removed. A read is bounded by pages and events; what it didn't reach waits in
`state` for the next read.
"""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta
from typing import Any
from urllib.parse import quote

from engine.plugin_api import ConnectorError, EventDetails, Poll, SourceItem
from pydantic import BaseModel, ConfigDict, Field

from cockpit_mail_calendar_common import require_scope

from .graph import GRAPH, PAGE_SIZE, SIGN_IN, Feed, Reader, body_text, find_by_name, person, stamp
from .sign_in import CALENDAR_NOT_ALLOWED, CALENDAR_SCOPE

PREFER = f'odata.maxpagesize={PAGE_SIZE}, outlook.timezone="UTC"'
_ANSWERS = {
    "none": "no answer yet",
    "notResponded": "no answer yet",
    "accepted": "accepted",
    "declined": "declined",
    "tentativelyAccepted": "tentative",
    "organizer": "organizer",
}
_SERIES = {"occurrence": "an occurrence of a series", "exception": "a changed occurrence of a series"}


class CalendarSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    calendars: list[str] = Field(
        default_factory=list, description="Calendar names to read. Empty means your default calendar."
    )
    days_back: int = Field(7, ge=0, le=365, description="How many days back the window of events reaches.")
    days_ahead: int = Field(60, ge=1, le=730, description="How many days ahead the window of events reaches.")
    max_events_per_read: int = Field(
        500, ge=1, le=5000, description="The most events one read hands in. The rest wait for the next read."
    )
    max_pages_per_read: int = Field(
        20, ge=1, le=200, description="The most pages one read asks the service for. The rest wait for the next read."
    )
    max_description_chars: int = Field(
        4000, ge=0, le=100000, description="How much of an event's description is kept. 0 keeps none."
    )


def _today() -> date:
    return datetime.now(UTC).date()


def _time(value: Any) -> datetime | None:
    """A Graph date-time such as 2026-10-12T09:00:00.0000000 (no zone), or None when it isn't one."""
    try:
        return datetime.fromisoformat(str(value)[:19])
    except ValueError:
        return None


def _when(event: dict[str, Any]) -> str:
    start, end = event.get("start") or {}, event.get("end") or {}
    first, last = _time(start.get("dateTime")), _time(end.get("dateTime"))
    if first is None:
        return ""
    if event.get("isAllDay"):
        final = last.date() - timedelta(days=1) if last and last > first else first.date()
        return (
            first.date().isoformat() if final <= first.date() else f"{first.date().isoformat()} – {final.isoformat()}"
        )
    zone = start.get("timeZone") or "UTC"
    text = f"{first:%Y-%m-%d %H:%M}"
    if last:
        text += f" – {last:%H:%M}" if last.date() == first.date() else f" – {last:%Y-%m-%d %H:%M}"
    text += f" {zone}"
    organizers = str(event.get("originalStartTimeZone") or "")
    if organizers and organizers.casefold() not in ("utc", "etc/utc"):
        text += f" (organizer's time zone: {organizers})"
    return text


def _details(event: dict[str, Any], place: str, join: str) -> EventDetails | None:
    """What Today's agenda needs: the times (UTC, as asked for), the place or else the join address, and whether it
    is called off. None when the event has no readable start. A recurring series is listed occurrence by occurrence,
    so `repeats` stays empty."""
    first, last = _time((event.get("start") or {}).get("dateTime")), _time((event.get("end") or {}).get("dateTime"))
    if first is None:
        return None
    all_day = bool(event.get("isAllDay"))
    if last is not None and last < first:
        last = None
    if all_day:
        start, end = first.date().isoformat(), last.date().isoformat() if last else None
    else:
        start, end = f"{first:%Y-%m-%dT%H:%M:%S}Z", f"{last:%Y-%m-%dT%H:%M:%S}Z" if last else None
    return EventDetails(
        start=start,
        end=end,
        all_day=all_day,
        where=place or join or None,
        cancelled=bool(event.get("isCancelled")),
    )


def event_item(event: dict[str, Any], max_description_chars: int) -> SourceItem:
    """One Graph event as a source item."""
    subject = str(event.get("subject") or "").strip()
    organizer = (event.get("organizer") or {}).get("emailAddress")
    attendees = []
    for attendee in event.get("attendees") or []:
        answer = str((attendee.get("status") or {}).get("response") or "none")
        kind = attendee.get("type") or "required"
        attendees.append(f"- {person(attendee.get('emailAddress'))} ({kind}): {_ANSWERS.get(answer, answer)}")
    meeting = event.get("onlineMeeting") or {}
    description = body_text(event.get("body"), max_description_chars)
    when = _when(event)
    place = str((event.get("location") or {}).get("displayName") or "").strip()
    join = str(meeting.get("joinUrl") or event.get("onlineMeetingUrl") or "")
    lines = [
        f"Subject: {subject}" if subject else "",
        f"When: {when}" if when else "",
        "All day: yes" if event.get("isAllDay") else "",
        "Status: Cancelled" if event.get("isCancelled") else "",
        f"Where: {place}" if place else "",
        f"Organizer: {person(organizer)}" if person(organizer) else "",
        "Attendees:" if attendees else "",
        *attendees,
        f"Online meeting: {join}" if join else "",
        f"Recurring: {_SERIES[event['type']]}" if event.get("type") in _SERIES else "",
        "Description:" if description else "",
        description,
    ]
    return SourceItem(
        key=str(event["id"]),
        title=subject or "(no subject)",
        text="\n".join(line for line in lines if line),
        author=(organizer or {}).get("address") or None,
        changed_at=event.get("lastModifiedDateTime"),
        link=event.get("webLink"),
        event=_details(event, place, join),
    )


def _feeds(
    reader: Reader, settings: CalendarSettings, window: dict[str, str], state: dict[str, Any]
) -> tuple[list[Feed], dict[str, str]]:
    """The calendars to read, and the name -> id list to remember."""
    names = [name.strip() for name in settings.calendars if name.strip()]
    if not names:
        return [Feed("default", f"{GRAPH}/me/calendarView/delta", delta=True, params=window)], {}
    listed = {  # id -> name, from the service
        str(c["id"]): str(c.get("name") or "")
        for c in reader.listing(f"{GRAPH}/me/calendars", {"$select": "id,name"}, counted=False)
        if c.get("id")
    }
    remembered = state.get("calendars") or {}
    found: dict[str, str] = {}
    for name in names:
        key = name.casefold()
        calendar_id = find_by_name(name, listed, remembered.get(key))
        if not calendar_id:
            raise ConnectorError("not_found", f"No calendar named {name}")
        found[key] = calendar_id
    # The per-calendar delta (/calendars/{id}/calendarView/delta) isn't confirmed for Graph v1.0, so a named
    # calendar is a complete listing of the window each read. To use a delta, set `delta=True` and add "/delta".
    feeds = {
        calendar_id: Feed(
            calendar_id, f"{GRAPH}/me/calendars/{quote(calendar_id, safe='')}/calendarView", delta=False, params=window
        )
        for calendar_id in found.values()
    }
    return list(feeds.values()), found


def _window(settings: CalendarSettings) -> dict[str, str]:
    today = _today()
    return {
        "startDateTime": stamp(today - timedelta(days=settings.days_back)),
        "endDateTime": stamp(today + timedelta(days=settings.days_ahead)),
    }


def _listed(
    listing: dict[str, Any], resuming: bool, seen: list[str], finished: bool, cap: int
) -> tuple[dict[str, Any], list[str]]:
    """What to remember about a named calendar's listing, and the ids that listing says are gone.

    `listing` is what was remembered: `done`, the ids of the last finished listing, and `so_far`, the ids of the
    listing under way (None when it grew past `cap` or its start wasn't kept). `seen` holds the ids of this listing
    so far. Removals are reported only when a listing finishes and the one before it is known.
    """
    tracked = (not resuming or isinstance(listing.get("so_far"), list)) and len(seen) <= cap
    done = listing.get("done")
    if not finished:
        return {"done": done, "so_far": seen if tracked else None}, []
    if not tracked:
        return {}, []  # too many to keep: no removals, and the next listing starts the count again
    now = set(seen)
    return {"done": seen}, [key for key in done if key not in now] if done is not None else []


def read_calendar(settings: CalendarSettings, state: dict[str, Any], context: Any) -> Poll:
    """Read the events in the window. Returns what was taken this time and what the service says is gone; `state`
    keeps where each calendar stands."""
    window = _window(settings)
    reader = Reader(
        context,
        prefer=PREFER,
        max_pages=settings.max_pages_per_read,
        max_items=settings.max_events_per_read,
        convert=lambda event, feed: event_item(event, settings.max_description_chars),
    )
    require_scope(context, SIGN_IN, CALENDAR_SCOPE, CALENDAR_NOT_ALLOWED)
    same_window = state.get("window") == window  # a moved or changed window starts fresh
    saved = (state.get("feeds") or {}) if same_window else {}
    listings = (state.get("listings") or {}) if same_window else {}
    feeds, remembered = _feeds(reader, settings, window, state)
    resume = state.get("resume") if same_window else None
    start = next((i for i, feed in enumerate(feeds) if feed.key == resume), 0)
    keep = {feed.key: saved.get(feed.key, {}) for feed in feeds}
    kept_listings = {feed.key: listings[feed.key] for feed in feeds if isinstance(listings.get(feed.key), dict)}
    cap = settings.max_events_per_read * 4
    gone: list[str] = []
    stopped = None
    for feed in feeds[start:] + feeds[:start]:
        if reader.full:
            stopped = stopped or feed.key
            break
        # A calendar read as a full listing has no list of deletions: what the last finished listing had and this
        # one doesn't is gone. The ids are collected across reads while a listing is under way.
        listing = kept_listings.get(feed.key, {})
        resuming = bool(keep[feed.key].get("next"))
        seen = list(listing.get("so_far") or []) if resuming and not feed.delta else []
        keep[feed.key], finished = reader.read_feed(feed, keep[feed.key], None if feed.delta else seen)
        if not feed.delta:
            kept_listings[feed.key], missing = _listed(listing, resuming, seen, finished, cap)
            gone += missing
        if not finished:
            stopped = feed.key
            break
    removed = [key for key in dict.fromkeys([*reader.removed, *gone]) if key not in reader.items]
    new_state = {"window": window, "calendars": remembered, "feeds": keep, "resume": stopped}
    if kept_listings:
        new_state["listings"] = kept_listings
    return Poll(items=list(reader.items.values()), state=new_state, complete=False, removed=removed)
