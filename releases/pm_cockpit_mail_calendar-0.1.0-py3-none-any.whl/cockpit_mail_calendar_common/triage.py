"""Triage for mail and calendar changes: the marker lines a connector adds from a message's own headers, and the rule
kinds that read them. Plugin code only. The three matchers are deterministic, quick and never call anything; each
plugin registers them under its own names."""

from __future__ import annotations

import re
from typing import Any

MAILING_LIST = "Sent as: mailing list"
AUTOMATIC_REPLY = "Sent as: automatic reply"
_ATTENDEE = re.compile(r"- \S.*: \S.*")  # "- Name <address> (kind): answer" or "- address: answer"


def sent_as(headers: Any) -> list[str]:
    """The marker lines for a message, from its headers (a list of `{"name": …, "value": …}`) and nothing else.

    A mailing list has a `List-Id` or `List-Unsubscribe` header, or `Precedence: bulk` or `list`. An automatic reply
    has an `Auto-Submitted` header with a value other than `no`, an `X-Autoreply` or `X-Autorespond` header, or
    `Precedence: auto_reply`. A message can be both, and then has both lines. Header names are not case-sensitive.
    """
    found: dict[str, str] = {}
    for header in headers if isinstance(headers, list) else []:
        if isinstance(header, dict) and header.get("name"):
            found.setdefault(str(header["name"]).strip().casefold(), str(header.get("value") or "").strip())
    precedence = found.get("precedence", "").casefold()
    automatic = found.get("auto-submitted", "").split(";")[0].strip().casefold()  # "auto-replied; owner=…"
    lines = []
    if "list-id" in found or "list-unsubscribe" in found or precedence in ("bulk", "list"):
        lines.append(MAILING_LIST)
    replying = ("x-autoreply" in found, "x-autorespond" in found, precedence == "auto_reply")
    if (automatic and automatic != "no") or any(replying):
        lines.append(AUTOMATIC_REPLY)
    return lines


def bulk(headers: Any) -> bool | None:
    """Whether a message says it was sent to many, from its headers (a list of `{"name": …, "value": …}`): it has a
    `List-Unsubscribe` header, or `Precedence` is `bulk` or `list`. False when the headers were read and say neither
    (`List-Id` alone does not count), None when `headers` isn't a list, because then the service didn't give them."""
    if not isinstance(headers, list):
        return None
    found: dict[str, str] = {}
    for header in headers:
        if isinstance(header, dict) and header.get("name"):
            found.setdefault(str(header["name"]).strip().casefold(), str(header.get("value") or "").strip())
    return "list-unsubscribe" in found or found.get("precedence", "").casefold() in ("bulk", "list")


def _params(params: Any, allowed: set[str]) -> dict[str, Any]:
    """The rule's params, or ValueError when they aren't a map or hold a name this rule doesn't know."""
    params = {} if params is None else params
    if not isinstance(params, dict):
        raise ValueError("a rule's params are a map")
    unknown = sorted(str(name) for name in params if name not in allowed)
    if unknown:
        takes = ", ".join(sorted(allowed)) or "none"
        raise ValueError(f"unknown param {', '.join(unknown)} (this rule takes {takes})")
    return params


def _marked(change: dict[str, Any], line: str) -> bool:
    """Whether a new or changed item's text has the marker `line` among its first lines, above the first blank line.
    The body is never looked at: a sender could write the line there."""
    if change.get("change") not in ("new", "changed"):
        return False
    head = str(change.get("now") or "").replace("\r\n", "\n").split("\n\n", 1)[0]
    return any(found.strip() == line for found in head.splitlines())


def _keep_from(value: Any) -> list[str]:
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list) or not all(isinstance(entry, str) for entry in value):
        raise ValueError("keep_from is a list of addresses or @domains")
    return [entry.strip().casefold() for entry in value if entry.strip()]


def mailing_lists(change: dict[str, Any], params: dict[str, Any] | None) -> str | None:
    """Close a new or changed message sent to a mailing list, unless its author is in `keep_from` (addresses, or
    `@domain`s, compared without regard to case)."""
    keep = _keep_from(_params(params, {"keep_from"}).get("keep_from", []))
    if not _marked(change, MAILING_LIST):
        return None
    author = str(change.get("author") or "").strip().casefold()
    if author and any(author.endswith(entry) if entry.startswith("@") else author == entry for entry in keep):
        return None
    return "Sent to a mailing list"


def automatic_replies(change: dict[str, Any], params: dict[str, Any] | None) -> str | None:
    """Close a new or changed message that is an automatic reply."""
    _params(params, set())
    return "An automatic reply" if _marked(change, AUTOMATIC_REPLY) else None


def _attendees(text: Any) -> set[str]:
    """The attendee lines of an event's text: the lines right under `Attendees:`."""
    lines = str(text or "").splitlines()
    start = next((i for i, line in enumerate(lines) if line.strip() == "Attendees:"), None)
    found: set[str] = set()
    for line in lines[start + 1 :] if start is not None else []:
        if not line.startswith("- "):
            break
        found.add(line)
    return found


def _who(line: str) -> str:
    """An attendee line without the answer: `- Name <address> (kind)`."""
    return line.rsplit(": ", 1)[0]


def answers_only(change: dict[str, Any], params: dict[str, Any] | None) -> str | None:
    """Close a changed calendar item when nothing but attendees' answers changed: every added and removed line is an
    attendee line, and each attendee that lost a line gained one (the same name and kind, a new answer). An attendee
    who was added or removed, or whose kind changed, is a real change and is left for the assistant."""
    _params(params, set())
    added, removed = list(change.get("added") or []), list(change.get("removed") or [])
    if change.get("change") != "changed" or not added or not removed:
        return None
    if not all(_ATTENDEE.fullmatch(line) for line in [*added, *removed]):
        return None
    if not set(added) <= _attendees(change.get("now")) or not set(removed) <= _attendees(change.get("before")):
        return None  # a bullet in the description looks like an attendee line
    if sorted(_who(line) for line in added) != sorted(_who(line) for line in removed):
        return None
    return "Only attendees' answers changed"
