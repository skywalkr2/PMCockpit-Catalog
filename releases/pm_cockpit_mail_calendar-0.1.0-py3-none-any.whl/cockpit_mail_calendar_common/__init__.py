"""Helpers both plugins use: plain text from HTML, clipping, and errors from the services' answers. Plugin code only."""

from __future__ import annotations

import json
import re
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

from engine.plugin_api import ConnectorError

_SKIPPED = {"script", "style", "head"}
_BLOCKS = {"p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote"}
_SPACES = re.compile(r"[ \t\r\n\xa0]+")
_CODE = re.compile(r"[A-Za-z0-9_. -]{1,80}")


def shipped_app(package_dir: str | Path) -> dict[str, str]:
    """The publisher's app registration shipped inside a plugin package: the strings of `app.json` next to the
    package's `__init__.py`. Empty when the file is missing, empty, unreadable, not a JSON object, or holds anything
    but non-empty strings. Never raises and never reports a value."""
    try:
        data = json.loads((Path(package_dir) / "app.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict) or not data:
        return {}
    if not all(isinstance(key, str) and isinstance(value, str) and value.strip() for key, value in data.items()):
        return {}
    return {key: value.strip() for key, value in data.items()}


def clip(text: str, max_chars: int) -> str:
    """Cut plain text to at most `max_chars`, ending with "…" when it was cut."""
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 1].rstrip() + "…" if max_chars > 0 else ""


class _Text(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skipping = 0
        self.at_line_start = True
        self.link: tuple[str, int] | None = None

    def _break(self, *, hard: bool = False) -> None:
        if hard or not self.at_line_start:
            self.parts.append("\n")
            self.at_line_start = True

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in _SKIPPED:
            self.skipping += 1
        elif self.skipping:
            return
        elif tag == "br":
            self._break(hard=True)
        elif tag in _BLOCKS:
            self._break()
            if tag == "li":
                self.parts.append("- ")
                self.at_line_start = False
        elif tag == "a":
            self.link = (dict(attrs).get("href") or "", len(self.parts))

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag: str) -> None:
        if tag in _SKIPPED:
            self.skipping = max(0, self.skipping - 1)
        elif self.skipping:
            return
        elif tag in _BLOCKS:
            self._break()
        elif tag == "a" and self.link:
            href, start = self.link
            self.link = None
            label = "".join(self.parts[start:]).strip()
            plain = href.removeprefix("mailto:")
            if label and href and not href.startswith(("#", "javascript:")) and label not in (href, plain):
                self.parts.append(f" ({href})")

    def handle_data(self, data: str) -> None:
        if self.skipping:
            return
        text = _SPACES.sub(" ", data)
        if text.strip() or not self.at_line_start:
            self.parts.append(text)
            self.at_line_start = False


def html_to_text(html: str, max_chars: int) -> str:
    """Plain text from HTML: no scripts or styles, one line per block, links as `text (address)`, cut at `max_chars`."""
    parser = _Text()
    parser.feed(html)
    parser.close()
    lines: list[str] = []
    for line in "".join(parser.parts).split("\n"):
        line = _SPACES.sub(" ", line).strip()
        if line or (lines and lines[-1]):
            lines.append(line)
    return clip("\n".join(lines).strip(), max_chars)


def _error_code(body: Any) -> str:
    """The service's own error code from an error body: Graph's `code`, or Google's `status` or first `reason`."""
    error = body.get("error") if isinstance(body, dict) else None
    candidates: list[Any] = []
    if isinstance(error, str):
        candidates.append(error)
    elif isinstance(error, dict):
        # Google's numeric `code` (such as 410) is no use; its `status` or first `reason` is the name.
        details = error.get("errors")
        reason = (
            details[0].get("reason") if isinstance(details, list) and details and isinstance(details[0], dict) else None
        )
        candidates += [error.get("code"), error.get("status"), reason]
    code = next((c for c in candidates if isinstance(c, str) and _CODE.fullmatch(c)), None)
    return code or "none"


def service_error(status: int, body: Any, service: str) -> ConnectorError:
    """The error for a status the web client hands back instead of raising. Decided from the status and the
    service's error code only, and the detail never quotes the body's message."""
    code = _error_code(body)
    if status == 400:
        return ConnectorError("outage", f"{service}: the service refused the request (status 400, code {code})")
    kind = "not_found" if status == 410 else "outage"
    return ConnectorError(kind, f"{service}: the service answered {status} (code {code})")


def scope_granted(allowed: set[str], scope: str) -> bool:
    """Whether `scope` is among the scopes the person `allowed`: written the same, or with the same part after the
    last `/` (Graph answers `Mail.Read` or `https://graph.microsoft.com/Mail.Read`; Google answers full addresses)."""
    tail = scope.rsplit("/", 1)[-1]
    return any(found == scope or found.rsplit("/", 1)[-1] == tail for found in allowed)


def require_scope(context: Any, sign_in: str, scope: str, words: str) -> None:
    """Raise `no_access` with `words` when the person didn't allow `scope` when they signed in. Call it after the
    sign-in's token is asked for (a withdrawn sign-in is `auth`, not this) and before the first request. A context that
    can't say what was allowed, such as a test's, allows everything."""
    granted = getattr(context, "granted", None)
    if granted is not None and not scope_granted(granted(sign_in), scope):
        raise ConnectorError("no_access", words)
