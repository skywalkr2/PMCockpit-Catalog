"""The exact Gmail and Google Calendar request each approved act makes, and the request that undoes it.

Pure functions: nothing here reaches the network, reads a context or registers anything. A channel looks up what
is needed (labels, the replied-to message, an event's attendees), asks for the request here, and makes it.
"""

from __future__ import annotations

import base64
import hashlib
from datetime import UTC, date, datetime
from email import policy
from email.message import EmailMessage
from email.parser import BytesParser
from email.utils import format_datetime
from typing import Any
from urllib.parse import quote

from engine.plugin_api import OutgoingAct

FALLBACK_DOMAIN = "pm-cockpit.invalid"
MESSAGE_ACTIONS = ("send", "reply", "reply_all", "forward")
MAILBOX_ACTIONS = ("archive", "move", "label", "mark_read")
ANSWERS = ("accepted", "tentative", "declined")
# Labels an act may never add through a folder or a label: they would delete, hide or re-mark mail.
_NOT_AS_A_LABEL = ("INBOX", "UNREAD", "TRASH", "SPAM")

Request = tuple[str, str, dict[str, str], dict[str, Any] | None]


# ---- messages ---------------------------------------------------------------------------------------------------


def message_id(attempt_key: str, account: str) -> str:
    """The Message-ID a sent message carries: the same key always gives the same id, so a lost answer can be settled
    by searching for it. `account` is `<kind>:<address>`."""
    digest = hashlib.sha256(attempt_key.encode("utf-8")).hexdigest()[:32]
    domain = account.rpartition("@")[2] if "@" in account else ""
    if not domain or any(c.isspace() or c in "<>@" for c in domain):
        domain = FALLBACK_DOMAIN
    return f"<pmc-{digest}@{domain}>"


def _plain(value: str, what: str) -> str:
    if "\r" in value or "\n" in value:
        raise ValueError(f"{what} has a line break in it")
    return value


def build_message(
    act: OutgoingAct,
    *,
    sender: str,
    message_id: str,
    original: dict | None = None,
    now: datetime | None = None,
) -> bytes:
    """The RFC 5322 message for a send, reply, reply to all or forward, with exactly the subject and body approved.
    `original` holds the replied-to (or forwarded) message's headers by lower-case name, and for a forward its
    `raw` bytes."""
    if act.kind != "message":
        raise ValueError(f"A {act.kind} act is not a message")
    if act.action not in MESSAGE_ACTIONS:
        raise ValueError(f"Google mail can't do '{act.action}' as a message")
    to = [_plain(r.address, "A recipient's address") for r in act.recipients if r.role == "to"]
    cc = [_plain(r.address, "A recipient's address") for r in act.recipients if r.role == "cc"]
    if not to and not cc:
        raise ValueError("The message has no recipients")
    if act.action in ("reply", "reply_all", "forward") and not original:
        raise ValueError(f"A {act.action.replace('_', ' ')} needs the message it answers")

    msg = EmailMessage(policy=policy.SMTP)
    msg["From"] = _plain(sender, "The sender")
    if to:
        msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = _plain(act.parts.get("subject", ""), "The subject")
    msg["Date"] = format_datetime(now or datetime.now(UTC))
    msg["Message-ID"] = _plain(message_id, "The message id")

    if act.action in ("reply", "reply_all"):
        assert original is not None
        replied_to = _plain(str(original.get("message-id") or "").strip(), "The replied-to message id")
        if not replied_to:
            raise ValueError("The message being replied to has no Message-ID")
        earlier = _plain(str(original.get("references") or "").strip(), "The references")
        msg["In-Reply-To"] = replied_to
        msg["References"] = f"{earlier} {replied_to}".strip()

    msg.set_content(act.parts.get("body", ""), charset="utf-8")

    if act.action == "forward":
        assert original is not None
        raw = original.get("raw")
        if not isinstance(raw, bytes | bytearray) or not raw:
            raise ValueError("A forward needs the original message")
        msg.add_attachment(BytesParser(policy=policy.SMTP).parsebytes(bytes(raw)))
    return msg.as_bytes()


def send_request(raw: bytes, thread_id: str | None = None) -> dict[str, str]:
    """The JSON body for `users.messages.send`: the message in base64url without padding, and the thread when given."""
    body = {"raw": base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")}
    if thread_id:
        body["threadId"] = thread_id
    return body


# ---- mailbox acts -----------------------------------------------------------------------------------------------


def _label_id(name: str | None, what: str, label_ids: dict[str, str]) -> str:
    if not name:
        raise ValueError(f"The act names no {what}")
    found = name if name in label_ids.values() else label_ids.get(name)
    if not found:
        raise ValueError(f"There is no {what} named '{name}' in this mailbox")
    if found in _NOT_AS_A_LABEL:
        raise ValueError(f"'{name}' can't be used as a {what}")
    return found


def mailbox_change(act: OutgoingAct, *, label_ids: dict[str, str]) -> tuple[dict, dict]:
    """The `users.messages.batchModify` body for a mailbox act, and the body that undoes it, for the messages the act
    is about. `label_ids` maps label names to Gmail label ids. Nothing is ever deleted or trashed."""
    if act.kind != "mailbox":
        raise ValueError(f"A {act.kind} act is not a mailbox act")
    if act.action not in MAILBOX_ACTIONS:
        raise ValueError(f"Google mail can't do '{act.action}' to messages")
    ids = [a.service_id for a in act.about if a.service_id]
    if not ids or len(ids) != len(act.about):
        raise ValueError("The act names no message to change")

    add: list[str] = []
    remove: list[str] = []
    if act.action == "archive":
        remove = ["INBOX"]
    elif act.action == "move":
        add, remove = [_label_id(act.folder, "folder", label_ids)], ["INBOX"]
    elif act.action == "label":
        add = [_label_id(act.label, "label", label_ids)]
    else:
        remove = ["UNREAD"]

    def body(adding: list[str], removing: list[str]) -> dict:
        found: dict[str, Any] = {"ids": list(ids)}
        if adding:
            found["addLabelIds"] = list(adding)
        if removing:
            found["removeLabelIds"] = list(removing)
        return found

    return body(add, remove), body(remove, add)


# ---- calendar acts ----------------------------------------------------------------------------------------------


def _calendar(act: OutgoingAct) -> str:
    return "primary" if act.calendar in (None, "", "own") else str(act.calendar)


def _events(act: OutgoingAct, event_id: str | None = None) -> str:
    path = f"/calendars/{quote(_calendar(act), safe='')}/events"
    return f"{path}/{quote(event_id, safe='')}" if event_id else path


def _event_id(act: OutgoingAct) -> str:
    found = next((a.service_id for a in act.about if a.service_id), None)
    if not found:
        raise ValueError("The act names no event")
    return found


def _moment(value: str | None, what: str) -> tuple[dict[str, str], date | datetime]:
    if not value:
        raise ValueError(f"The event has no {what}")
    try:
        if "T" not in value and " " not in value:
            day = date.fromisoformat(value)
            return {"date": day.isoformat()}, day
        moment = datetime.fromisoformat(value)
    except ValueError:
        raise ValueError(f"The event's {what} isn't a date or a time") from None
    if moment.tzinfo is None:
        raise ValueError(f"The event's {what} needs a time zone offset")
    return {"dateTime": moment.isoformat()}, moment


def _span(act: OutgoingAct) -> tuple[dict[str, str], dict[str, str]]:
    start, first = _moment(act.start, "start")
    end, last = _moment(act.end, "end")
    if isinstance(first, datetime) != isinstance(last, datetime):
        raise ValueError("The event's start and end must both be dates or both be times")
    if last < first:  # type: ignore[operator]
        raise ValueError("The event ends before it starts")
    return start, end


def _calendar_act(act: OutgoingAct, action: str) -> None:
    if act.kind != "calendar":
        raise ValueError(f"A {act.kind} act is not a calendar act")
    if act.action != action:
        raise ValueError(f"A '{act.action}' act is not a calendar '{action}'")


def create_event(act: OutgoingAct) -> Request:
    """The request that creates an event, with its attendees (invitations go out) and any reminder."""
    _calendar_act(act, "create")
    if not act.title:
        raise ValueError("The event has no title")
    start, end = _span(act)
    body: dict[str, Any] = {"summary": act.title, "start": start, "end": end}
    if act.parts.get("body"):
        body["description"] = act.parts["body"]
    attendees = [{"email": r.address} for r in act.recipients]
    if attendees:
        body["attendees"] = attendees
    if act.alarm_minutes is not None:
        body["reminders"] = {
            "useDefault": False,
            "overrides": [{"method": "popup", "minutes": act.alarm_minutes}],
        }
    return "POST", _events(act), {"sendUpdates": "all" if attendees else "none"}, body


def undo_create(event_id: str, calendar: str | None = None) -> Request:
    """The request that takes a created event back: it is deleted, and nobody is told."""
    if not event_id:
        raise ValueError("The act names no event")
    path = f"/calendars/{quote('primary' if calendar in (None, '', 'own') else str(calendar), safe='')}/events"
    return "DELETE", f"{path}/{quote(event_id, safe='')}", {"sendUpdates": "none"}, None


def move_event(act: OutgoingAct) -> Request:
    """The request that gives an event new times; the attendees are told."""
    _calendar_act(act, "move")
    event_id = _event_id(act)
    start, end = _span(act)
    return "PATCH", _events(act, event_id), {"sendUpdates": "all"}, {"start": start, "end": end}


def cancel_event(act: OutgoingAct) -> Request:
    """The request that cancels an event; the attendees are told."""
    _calendar_act(act, "cancel")
    return "DELETE", _events(act, _event_id(act)), {"sendUpdates": "all"}, None


def answer_event(act: OutgoingAct, *, attendees: list[dict]) -> Request:
    """The request that answers an invitation: the event's current `attendees` with only the account's own entry
    changed to the answer (and the comment, when there is one)."""
    _calendar_act(act, "answer")
    if act.answer == "propose":
        raise ValueError("Google Calendar can't propose a new time")
    if act.answer not in ANSWERS:
        raise ValueError(f"'{act.answer}' isn't an answer to an invitation")
    event_id = _event_id(act)
    address = (act.account or "").partition(":")[2].strip().lower()
    comment = act.parts.get("comment")
    found = False
    updated = []
    for entry in attendees:
        entry = dict(entry)
        own = entry.get("self") is True or (address and str(entry.get("email", "")).strip().lower() == address)
        if own and not found:
            found = True
            entry["responseStatus"] = act.answer
            if comment:
                entry["comment"] = comment
        updated.append(entry)
    if not found:
        raise ValueError("You are not among the people invited to this event")
    return "PATCH", _events(act, event_id), {"sendUpdates": "all"}, {"attendees": updated}
