"""The Gmail and Google Calendar channels: how an act the person approved is carried out.

A channel is called only by the host's publisher, for an act the person said yes to. It looks up what the act needs,
makes the request `acting.py` describes, and answers `ChannelSent`, `ChannelFailed` (only when it is sure nothing went
out) or `ChannelUnknown` (an outage, throttling or a timeout on the request that does the act: it may have gone
through). `status` never says "not sent". Nothing here deletes or bins mail.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
from collections.abc import Callable
from typing import Any
from urllib.parse import quote, urlsplit

from engine.plugin_api import (
    ChannelContext,
    ChannelFailed,
    ChannelFolder,
    ChannelSent,
    ChannelUndone,
    ChannelUnknown,
    ConnectorError,
    OutgoingAct,
)

from cockpit_mail_calendar_common import scope_granted

from . import acting
from .api import CALENDAR, GMAIL, RATE_LIMITS, _api_turned_off
from .sign_in import ACTING_SCOPES

MAIL_CHANNEL = "google/mail-channel"
CALENDAR_CHANNEL = "google/calendar-channel"
MAIL_SCOPE, CALENDAR_SCOPE = ACTING_SCOPES
ACTING_NOT_ALLOWED = (
    "Acting isn't allowed for this account yet. Turn on acting for it again and allow it on Google's page."
)
#: The most messages one `batchModify` takes.
MAX_MESSAGES = 1000
#: Google's reasons (or status names) that say the sign-in lacks the scope this request needs.
_SCOPE_CODES = {"insufficientPermissions", "ACCESS_TOKEN_SCOPE_INSUFFICIENT"}

Answer = ChannelSent | ChannelFailed | ChannelUnknown


def attempt_hash(attempt_key: str) -> str:
    """The first 32 hex characters of the key's SHA-256: what an event carries so a lost answer can be settled."""
    return hashlib.sha256(attempt_key.encode("utf-8")).hexdigest()[:32]


class _Stop(Exception):
    """Ends the work with this answer."""

    def __init__(self, answer: Answer):
        super().__init__(str(answer))
        self.answer = answer


def _codes(err: ConnectorError | None, body: Any = None) -> list[str]:
    """Google's own error codes from an error body: every `reason` in `error.errors` and `error.details`, then
    `error.status`. Codes only, never the message."""
    if body is None and err is not None:
        body = err.json()
    error = body.get("error") if isinstance(body, dict) else None
    if not isinstance(error, dict):
        return []
    found: list[str] = []
    for key in ("errors", "details"):
        entries = error.get(key)
        for entry in entries if isinstance(entries, list) else []:
            reason = entry.get("reason") if isinstance(entry, dict) else None
            if isinstance(reason, str) and reason:
                found.append(reason)
    if isinstance(error.get("status"), str):
        found.append(error["status"])
    return found


def _code_words(codes: list[str]) -> str:
    code = next((c for c in codes if c.replace("_", "").replace("-", "").isalnum() and len(c) <= 80), None)
    return code or "none"


def _json(content: bytes) -> Any:
    import json

    try:
        return json.loads(content)
    except ValueError:
        return None


class _Call:
    """The requests of one call, with the account's token. `lookup` is a request made before the act; `act` is the
    request that does it, whose failure to answer may mean it went through."""

    def __init__(self, context: ChannelContext, scope: str | None, *, undoing: bool = False):
        self.context = context
        self.undoing = undoing
        self.account = context.account or ""
        self.who = self.account.partition(":")[2] or self.account or "your Google account"
        self.acted = False
        self.headers = {"Authorization": f"Bearer {self._token()}"}
        if scope is not None and not scope_granted(set(context.granted or ()), scope):
            raise _Stop(ChannelFailed("refused", ACTING_NOT_ALLOWED))

    def _token(self) -> str:
        try:
            token = self.context.access_token()
        except ConnectorError as err:
            if err.kind == "offline":
                raise _Stop(ChannelFailed("offline", "Couldn't reach Google. Check the connection.")) from None
            if err.kind in ("auth", "no_access"):
                raise _Stop(ChannelFailed("auth", f"Sign in to {self.who} again.")) from None
            raise _Stop(ChannelFailed("outage", "Google's sign-in couldn't be renewed just now.")) from None
        if not token:
            raise _Stop(ChannelFailed("auth", f"Sign in to {self.who} again."))
        return token

    def address(self) -> str:
        """The signed-in address, which is the sender."""
        address = self.who.strip()
        if "@" not in address or any(c.isspace() or c in "<>" for c in address):
            raise ValueError("The account has no address to send from")
        return address

    # ---- requests ------------------------------------------------------------------------------------------------

    def lookup(self, url: str, params: dict | None = None) -> Any:
        """A GET made before the act. Returns the decoded JSON object; any failure is `ChannelFailed`."""
        _, body = self._send("GET", url, params, None, acts=False)
        if not isinstance(body, dict):
            raise _Stop(ChannelFailed("outage", "Google's answer couldn't be read."))
        return body

    def act(
        self, method: str, url: str, params: dict | None = None, body: dict | None = None, *, gone_ok: bool = False
    ) -> tuple[int, Any]:
        """The request that does the act. With `gone_ok`, an event that is already gone (404 or 410) is done."""
        _never_deletes_mail(method, url, body)  # before anything is marked as made
        self.acted = not self.undoing
        return self._send(method, url, params, body, acts=not self.undoing, gone_ok=gone_ok)

    def _send(
        self, method: str, url: str, params: dict | None, body: dict | None, *, acts: bool, gone_ok: bool = False
    ) -> tuple[int, Any]:
        _never_deletes_mail(method, url, body)
        web = self.context.web
        call: Callable[..., Any] = {
            "GET": web.get,
            "POST": web.post,
            "PATCH": web.patch,
            "DELETE": web.delete,
        }[method]
        arguments: dict[str, Any] = {"headers": self.headers}
        if params:
            arguments["params"] = params
        if body is not None:
            arguments["json"] = body
        try:
            response = call(url, **arguments)
        except ConnectorError as err:
            if gone_ok and err.kind == "not_found":
                return 404, None
            raise _Stop(self._from_error(err, acts)) from None
        status = response.status
        decoded = _json(response.content) if response.content else None
        if 200 <= status < 300:
            return status, decoded
        if gone_ok and status in (404, 410):
            return status, decoded
        if status == 408 or not 400 <= status < 500:
            # A request timeout, a redirect or anything else unexpected: no clear answer.
            raise _Stop(self._unclear(acts, f"Google answered {status}"))
        raise _Stop(ChannelFailed("refused", self._refusal(status, _codes(None, decoded))))

    def _unclear(self, acts: bool, why: str) -> Answer:
        if acts:
            return ChannelUnknown()
        return ChannelFailed("outage", f"{why}. Try again in a little while.")

    def _refusal(self, status: int | None, codes: list[str]) -> str:
        if _SCOPE_CODES & set(codes):
            return ACTING_NOT_ALLOWED
        return f"Google refused it (status {status if status is not None else 'none'}, code {_code_words(codes)})."

    def _from_error(self, err: ConnectorError, acts: bool) -> Answer:
        codes = _codes(err)
        if err.kind == "auth":
            return ChannelFailed("auth", f"Sign in to {self.who} again.")
        if err.kind == "no_access":
            if RATE_LIMITS & set(codes):
                return self._unclear(acts, "Google asked to wait")
            if _api_turned_off(err):
                return ChannelFailed(
                    "refused", "Google's API for this is turned off in the project of the app you signed in with."
                )
            return ChannelFailed("refused", self._refusal(err.status, codes))
        if err.kind == "not_found":
            return ChannelFailed("refused", "Google says it isn't there (status 404).")
        if err.kind == "offline":
            return ChannelFailed("offline", "Couldn't reach Google. Check the connection and try again.")
        # outage, throttled, or anything else: the service did not answer clearly.
        return self._unclear(acts, "Google didn't answer clearly")


def _never_deletes_mail(method: str, url: str, body: dict | None) -> None:
    """Refuses any Gmail request that could delete or bin mail, whatever asked for it."""
    parts = urlsplit(url)
    if (parts.hostname or "").lower() == "gmail.googleapis.com":
        path = parts.path.lower()
        if method == "DELETE" or "trash" in path or "delete" in path:
            raise ValueError("Mail is never deleted or put in the bin")
    if isinstance(body, dict):
        for key in ("addLabelIds", "removeLabelIds"):
            if any(str(label).upper() == "TRASH" for label in body.get(key) or ()):
                raise ValueError("Mail is never deleted or put in the bin")


def _run(
    context: ChannelContext, scope: str | None, work: Callable[[_Call], Answer], *, undoing: bool = False
) -> Answer:
    """Runs `work` with a call. A refusal before any request is `refused`; the same after the act's request was made
    is `ChannelUnknown`, because the act may have gone through."""
    call: _Call | None = None
    try:
        call = _Call(context, scope, undoing=undoing)
        return work(call)
    except _Stop as stop:
        return stop.answer
    except ValueError as err:
        if call is not None and call.acted:
            return ChannelUnknown()
        return ChannelFailed("refused", str(err))


def _first_id(act: OutgoingAct, what: str) -> str:
    found = next((a.service_id for a in act.about if a.service_id), None)
    if not found:
        raise ValueError(f"The act names no {what}")
    return found


def _sent_id(body: Any, fallback: str | None = None) -> Answer:
    found = body.get("id") if isinstance(body, dict) else None
    if isinstance(found, str) and found:
        return ChannelSent(found)
    # It was accepted but the answer didn't say which: status can find it by its key.
    return ChannelSent(fallback) if fallback else ChannelUnknown()


# ---- mail -------------------------------------------------------------------------------------------------------


def _headers(message: dict) -> dict[str, str]:
    """A message's headers by lower-case name (the first of each), from a `format=metadata` answer."""
    entries = (message.get("payload") or {}).get("headers")
    found: dict[str, str] = {}
    for entry in entries if isinstance(entries, list) else []:
        if isinstance(entry, dict) and isinstance(entry.get("name"), str) and isinstance(entry.get("value"), str):
            found.setdefault(entry["name"].lower(), entry["value"])
    return found


def _label_ids(call: _Call) -> dict[str, str]:
    body = call.lookup(f"{GMAIL}/labels")
    labels = body.get("labels")
    return {
        entry["name"]: entry["id"]
        for entry in labels if isinstance(labels, list) and isinstance(entry, dict)
        if isinstance(entry.get("name"), str) and isinstance(entry.get("id"), str)
    }  # fmt: skip


#: System labels a person files to, by the name Gmail shows. Every other system label is left out.
_FILING_SYSTEM_LABELS = {"STARRED": "Starred", "IMPORTANT": "Important"}


def folders(account: str, context: ChannelContext) -> list[ChannelFolder] | ChannelFailed:
    """The labels Move to and Label offer: the person's own, plus Starred and Important. Gmail has no folders, so
    each is listed as a folder and as a label with the same id. Read-only: one request."""

    def work(call: _Call) -> Any:
        body = call.lookup(f"{GMAIL}/labels")
        entries = body.get("labels")
        found: dict[str, str] = {}
        for entry in entries if isinstance(entries, list) else []:
            if not isinstance(entry, dict) or not isinstance(entry.get("id"), str) or not entry["id"]:
                continue
            if entry.get("type") == "user" and isinstance(entry.get("name"), str) and entry["name"]:
                found[entry["id"]] = entry["name"]
            elif entry["id"] in _FILING_SYSTEM_LABELS:
                found[entry["id"]] = _FILING_SYSTEM_LABELS[entry["id"]]
        ordered = sorted(found.items(), key=lambda pair: (pair[1].casefold(), pair[1], pair[0]))
        return [ChannelFolder(id=i, name=n, kind=k) for i, n in ordered for k in ("folder", "label")]

    return _run(context, None, work)  # type: ignore[return-value]


def _send_message(call: _Call, act: OutgoingAct, attempt_key: str) -> Answer:
    sender = call.address()
    wanted = act.action in ("reply", "reply_all", "forward")
    original: dict | None = None
    thread: str | None = None
    if wanted:
        original_id = quote(_first_id(act, "message to answer"), safe="")
        if act.action == "forward":
            message = call.lookup(f"{GMAIL}/messages/{original_id}", {"format": "raw"})
            raw = message.get("raw")
            try:
                decoded = base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)) if isinstance(raw, str) else b""
            except (binascii.Error, ValueError):
                decoded = b""
            original = {"raw": decoded}
        else:
            message = call.lookup(
                f"{GMAIL}/messages/{original_id}",
                {"format": "metadata", "metadataHeaders": ["Message-ID", "References"]},
            )
            original = _headers(message)
            thread = message.get("threadId") if isinstance(message.get("threadId"), str) else None
    mime = acting.build_message(
        act, sender=sender, message_id=acting.message_id(attempt_key, call.account), original=original
    )
    _, body = call.act("POST", f"{GMAIL}/messages/send", body=acting.send_request(mime, thread))
    return _sent_id(body)


def _change_mailbox(call: _Call, act: OutgoingAct) -> Answer:
    if len([a for a in act.about if a.service_id]) > MAX_MESSAGES:
        raise ValueError(f"Gmail changes at most {MAX_MESSAGES} messages at a time")
    labels = _label_ids(call) if act.action in ("move", "label") else {}
    do, _ = acting.mailbox_change(act, label_ids=labels)
    call.act("POST", f"{GMAIL}/messages/batchModify", body=do)
    return ChannelSent(do["ids"][0])


def send_mail(act: OutgoingAct, attempt_key: str, context: ChannelContext) -> Answer:
    """Carry out an approved message or mailbox act."""

    def work(call: _Call) -> Answer:
        if act.kind == "message":
            return _send_message(call, act, attempt_key)
        if act.kind == "mailbox":
            return _change_mailbox(call, act)
        raise ValueError(f"Gmail can't do a {act.kind} act")

    return _run(context, MAIL_SCOPE, work)


# ---- calendar ---------------------------------------------------------------------------------------------------


def _calendar_act(call: _Call, act: OutgoingAct, attempt_key: str) -> Answer:
    if act.action == "create":
        method, path, params, body = acting.create_event(act)
        body = {**(body or {}), "extendedProperties": {"private": {"pmcAttempt": attempt_hash(attempt_key)}}}
        _, answer = call.act(method, CALENDAR + path, params, body)
        return _sent_id(answer)
    if act.action == "answer":
        # Check the act is fit to make before any request: a stand-in attendee that is "self" passes only if it is.
        acting.answer_event(act, attendees=[{"self": True}])
        event = call.lookup(CALENDAR + acting._events(act, acting._event_id(act)))
        attendees = event.get("attendees")
        method, path, params, body = acting.answer_event(
            act, attendees=[a for a in attendees if isinstance(a, dict)] if isinstance(attendees, list) else []
        )
    elif act.action == "move":
        method, path, params, body = acting.move_event(act)
    elif act.action == "cancel":
        method, path, params, body = acting.cancel_event(act)
    else:
        raise ValueError(f"Google Calendar can't do '{act.action}'")
    call.act(method, CALENDAR + path, params, body, gone_ok=act.action == "cancel")
    return ChannelSent(acting._event_id(act))


def send_calendar(act: OutgoingAct, attempt_key: str, context: ChannelContext) -> Answer:
    """Carry out an approved calendar act."""

    def work(call: _Call) -> Answer:
        if act.kind != "calendar":
            raise ValueError(f"Google Calendar can't do a {act.kind} act")
        return _calendar_act(call, act, attempt_key)

    return _run(context, CALENDAR_SCOPE, work)


# ---- undo -------------------------------------------------------------------------------------------------------

CANT_TAKE_BACK = "This can't be taken back here. Look in Gmail or Google Calendar."


def undo_mail(act: OutgoingAct, service_id: str, context: ChannelContext) -> ChannelUndone | ChannelFailed:
    """Take a filing change or read mark back: the reverse `batchModify` for the same messages."""

    def work(call: _Call) -> Answer:
        if act.kind != "mailbox":
            return ChannelFailed("refused", CANT_TAKE_BACK)
        if len([a for a in act.about if a.service_id]) > MAX_MESSAGES:
            raise ValueError(f"Gmail changes at most {MAX_MESSAGES} messages at a time")
        labels = _label_ids(call) if act.action in ("move", "label") else {}
        _, undo = acting.mailbox_change(act, label_ids=labels)
        call.act("POST", f"{GMAIL}/messages/batchModify", body=undo)
        return ChannelUndone()

    return _run(context, MAIL_SCOPE, work, undoing=True)  # type: ignore[return-value]


def undo_calendar(act: OutgoingAct, service_id: str, context: ChannelContext) -> ChannelUndone | ChannelFailed:
    """Take a created event back: it is deleted, and nobody is told. Already gone counts as done."""

    def work(call: _Call) -> Answer:
        if act.kind != "calendar" or act.action != "create":
            return ChannelFailed("refused", CANT_TAKE_BACK)
        method, path, params, body = acting.undo_create(service_id, act.calendar)
        call.act(method, CALENDAR + path, params, body, gone_ok=True)
        return ChannelUndone()

    return _run(context, CALENDAR_SCOPE, work, undoing=True)  # type: ignore[return-value]


# ---- status -----------------------------------------------------------------------------------------------------


def _found(context: ChannelContext, search: Callable[[_Call], Any], key: str) -> Answer:
    """Looks for what an attempt left behind. Found is `ChannelSent`; anything else, a failure included, is unknown:
    a search can lag behind a send, so "nothing found" never means "not sent"."""
    try:
        body = search(_Call(context, None))
    except (_Stop, ValueError):
        return ChannelUnknown()
    items = body.get(key) if isinstance(body, dict) else None
    first = items[0] if isinstance(items, list) and items else None
    found = first.get("id") if isinstance(first, dict) else None
    return ChannelSent(found) if isinstance(found, str) and found else ChannelUnknown()


def mail_status(attempt_key: str, context: ChannelContext) -> Answer:
    """What became of a send: the message with the Message-ID this attempt used, if Gmail has it."""

    def search(call: _Call) -> Any:
        wanted = acting.message_id(attempt_key, call.account).strip("<>")
        return call.lookup(
            f"{GMAIL}/messages", {"q": f"rfc822msgid:{wanted}", "includeSpamTrash": "true", "maxResults": "1"}
        )

    return _found(context, search, "messages")


def calendar_status(attempt_key: str, context: ChannelContext) -> Answer:
    """What became of a create: the event carrying this attempt's mark, on the main calendar."""

    def search(call: _Call) -> Any:
        return call.lookup(
            f"{CALENDAR}/calendars/primary/events",
            {
                "privateExtendedProperty": f"pmcAttempt={attempt_hash(attempt_key)}",
                "showDeleted": "true",
                "maxResults": "1",
            },
        )

    return _found(context, search, "items")


__all__ = [
    "ACTING_NOT_ALLOWED",
    "CALENDAR_CHANNEL",
    "MAIL_CHANNEL",
    "attempt_hash",
    "calendar_status",
    "folders",
    "mail_status",
    "send_calendar",
    "send_mail",
    "undo_calendar",
    "undo_mail",
]
