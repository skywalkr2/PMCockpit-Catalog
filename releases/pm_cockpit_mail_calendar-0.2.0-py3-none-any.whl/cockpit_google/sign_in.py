"""What the Google sign-in asks, what it tells the person it asks, and how it names the signed-in account."""

from __future__ import annotations

from typing import Any

from engine.plugin_api import ConnectorError

from .api import CALENDAR, GMAIL, Reader

MAIL_SCOPE = "https://www.googleapis.com/auth/gmail.readonly"
CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar.readonly"
SCOPES = (MAIL_SCOPE, CALENDAR_SCOPE)
#: Asked for only when the person turns acting on: sending and changing mail, and writing events.
ACTING_SCOPES = ("https://www.googleapis.com/auth/gmail.modify", "https://www.googleapis.com/auth/calendar.events")
REVOKE_URL = "https://oauth2.googleapis.com/revoke"
#: What the person is told before they leave for Google's page. Each line is at most 80 characters.
ALLOWS = (
    "Read your Gmail (it never deletes anything)",
    "Read your Google Calendar",
    "Stay signed in, so it can keep reading while you're away",
    "If you turn on acting, it asks once more to send and change mail and events",
)
#: What using the publisher's app registration means for the person (the host shows it while that registration is used).
#: The callback addresses the publisher's registration allows (a loopback host matches any port). At any other address
#: (another base path, a hosted app) PM Cockpit asks the person for their own registration instead.
DEFAULT_REDIRECTS = ("http://localhost/api/sign-ins/callback", "http://127.0.0.1/api/sign-ins/callback")
DEFAULT_APP_NOTE = (
    "This uses the add-on publisher's app registration. While it is in testing, only people the publisher has added "
    "as testers can sign in, Google shows a page saying the app isn't verified (choose Continue), and it asks you to "
    "sign in again every 7 days."
)
#: How a person makes their own app registration: a line, or a line with the https page to open for it.
OWN_APP_STEPS = (
    ("Create a project in Google Cloud", "https://console.cloud.google.com/projectcreate"),
    ("Turn on the Gmail API", "https://console.cloud.google.com/apis/library/gmail.googleapis.com"),
    ("Turn on the Google Calendar API", "https://console.cloud.google.com/apis/library/calendar-json.googleapis.com"),
    (
        "Set up the consent screen: Internal for a Google Workspace account, otherwise External",
        "https://console.cloud.google.com/auth/overview",
    ),
    ("External only: add your own address under Test users", "https://console.cloud.google.com/auth/audience"),
    (
        "Add the scopes gmail.readonly and calendar.readonly, plus gmail.modify and calendar.events for acting",
        "https://console.cloud.google.com/auth/scopes",
    ),
    ("Create an OAuth client of type Desktop app", "https://console.cloud.google.com/auth/clients/create"),
    "A Desktop app client already allows the address shown here, so there is nothing to add",
    "Paste the client ID and client secret here",
)
#: What reading starts as soon as the person signs in: the inbox, the sent mail and the main calendar.
SOURCES = (
    {"connector": "google/mail", "label": "Your inbox", "settings": {}, "every_minutes": 15},
    {
        "connector": "google/mail",
        "label": "Your sent mail",
        "settings": {"labels": ["SENT"]},
        "every_minutes": 15,
        "sent": True,
    },
    {"connector": "google/calendar", "label": "Your calendar", "settings": {}, "every_minutes": 15},
)
MAIL_NOT_ALLOWED = "Reading mail wasn't allowed when you signed in. Sign in again and allow it."
CALENDAR_NOT_ALLOWED = "Reading your calendar wasn't allowed when you signed in. Sign in again and allow it."
MAIL_API_OFF = (
    "The Gmail API is turned off in the Google Cloud project of the app you signed in with. Whoever manages that app "
    "(you, if you pasted your own) can turn it on at https://console.cloud.google.com/apis/library/gmail.googleapis.com"
)
CALENDAR_API_OFF = (
    "The Google Calendar API is turned off in the Google Cloud project of the app you signed in with. Whoever manages "
    "that app (you, if you pasted your own) can turn it on at "
    "https://console.cloud.google.com/apis/library/calendar-json.googleapis.com"
)


def account(context: Any) -> str:
    """The signed-in account's address: from the Gmail profile, or from the primary calendar's id when Gmail wasn't
    allowed (a primary calendar is named by its owner's address). No extra scope is asked for."""
    reader = Reader(context, max_pages=2, max_items=1)
    try:
        address = reader.fetch(f"{GMAIL}/profile", counted=False).get("emailAddress")
    except ConnectorError as err:
        if err.kind != "no_access":
            raise
        address = reader.fetch(f"{CALENDAR}/calendars/primary", {"fields": "id"}, counted=False).get("id")
    if not isinstance(address, str) or not address.strip():
        raise ConnectorError("outage", "Google: the answer named no account")
    return address.strip()
