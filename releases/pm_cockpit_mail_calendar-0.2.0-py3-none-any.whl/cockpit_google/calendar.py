"""The Google Calendar connector: events in a window around today, read through the Calendar API. Read-only.

A calendar is read in full once, and then with the sync token Google hands back (only what changed since). A sync
token can't be combined with a window, so the changes it brings are filtered to the window here. A read is bounded
by pages and events; what it didn't reach waits in `state` for the next read.
"""

from __future__ import annotations

from datetime import UTC, date, datetime, time, timedelta
from typing import Any
from urllib.parse import quote

from engine.plugin_api import ConnectorError, EventDetails, Poll, SourceItem
from pydantic import BaseModel, ConfigDict, Field

from cockpit_mail_calendar_common import clip, html_to_text, looks_like_html, require_scope

from .api import CALENDAR, SIGN_IN, Feed, Reader, find_by_name, person, stamp
from .sign_in import CALENDAR_API_OFF, CALENDAR_NOT_ALLOWED, CALENDAR_SCOPE

BASE_QUERY = {"singleEvents": "true", "maxResults": "100"}
_ANSWERS = {
    "needsAction": "no answer yet",
    "accepted": "accepted",
    "declined": "declined",
    "tentative": "tentative",
}


class CalendarSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    calendars: list[str] = Field(
        default_factory=list, description="Calendar names to read. Empty means your primary calendar."
    )
    days_back: int = Field(7, ge=0, le=365, description="How many days back the window of events reaches.")
    days_ahead: int = Field(60, ge=1, le=730, description="How many days ahead the window of events reaches.")
    max_events_per_read: int = Field(
        500, ge=1, le=5000, description="The most events one read hands in. The rest wait for the next read."
    )
    max_pages_per_read: int = Field(
        20, ge=1, le=200, description="The most pages one read asks the service for. The rest wait for the next read."
    )
    max_description_chars: int = Field(
        4000, ge=0, le=100000, description="How much of an event's description is kept. 0 keeps none."
    )
    throttle_wait_seconds: int = Field(
        60,
        ge=1,
        le=3600,
        description=(
            "Seconds to wait before reading again when Google says there are too many requests but not for how long."
        ),
    )


def _today() -> date:
    return datetime.now(UTC).date()


def _moment(part: Any) -> datetime | None:
    """A Google `start` or `end` (a `dateTime` with an offset, or an all-day `date`) as a moment, or None."""
    part = part if isinstance(part, dict) else {}
    try:
        if part.get("dateTime"):
            moment = datetime.fromisoformat(str(part["dateTime"]))
            return moment if moment.tzinfo else moment.replace(tzinfo=UTC)
        if part.get("date"):
            return datetime.combine(date.fromisoformat(str(part["date"])), time.min, UTC)
    except ValueError:
        pass
    return None


def _offset(moment: datetime) -> str:
    """The offset of a moment as `UTC-07:00` (`UTC` for none), or "" when it has none."""
    delta = moment.utcoffset()
    if delta is None:
        return ""
    minutes = int(delta.total_seconds() // 60)
    if minutes == 0:
        return "UTC"
    sign, minutes = ("+", minutes) if minutes > 0 else ("-", -minutes)
    return f"UTC{sign}{minutes // 60:02}:{minutes % 60:02}"


def _when(event: dict[str, Any]) -> str:
    start, end = event.get("start") or {}, event.get("end") or {}
    first, last = _moment(start), _moment(end)
    if first is None:
        return ""
    if not start.get("dateTime"):  # all day: Google's end date is the day after the last one
        final = last.date() - timedelta(days=1) if last and last > first else first.date()
        return (
            first.date().isoformat() if final <= first.date() else f"{first.date().isoformat()} – {final.isoformat()}"
        )
    text = f"{first:%Y-%m-%d %H:%M}"
    if last:
        text += f" – {last:%H:%M}" if last.date() == first.date() else f" – {last:%Y-%m-%d %H:%M}"
    notes = ", ".join(dict.fromkeys(note for note in (str(start.get("timeZone") or ""), _offset(first)) if note))
    return f"{text} ({notes})" if notes else text


def _description(text: Any, max_chars: int) -> str:
    """An event's description as plain text. Google keeps HTML in it (and plain text from other programs): only text
    that has HTML tags in it goes through the HTML reader, which would run plain lines together."""
    text = str(text or "")
    if looks_like_html(text):
        return html_to_text(text, max_chars)
    return clip(text.replace("\r\n", "\n").replace("\r", "\n").strip(), max_chars)


def _meeting(event: dict[str, Any]) -> str:
    """Where to join: the Meet link, or the first video entry point of the conference."""
    if event.get("hangoutLink"):
        return str(event["hangoutLink"])
    points = (event.get("conferenceData") or {}).get("entryPoints") or []
    return next((str(p["uri"]) for p in points if p.get("entryPointType") == "video" and p.get("uri")), "")


def _stated(part: Any, all_day: bool) -> tuple[str, datetime | date] | None:
    """A Google `start` or `end` as the text to pass on and its value, or None when it isn't readable. An all-day
    entry has a `date`; a timed one has a `dateTime` that carries its offset."""
    part = part if isinstance(part, dict) else {}
    try:
        if all_day:
            text = str(part.get("date") or "")
            return (text, date.fromisoformat(text)) if len(text) == 10 else None
        text = str(part.get("dateTime") or "")
        moment = datetime.fromisoformat(text.replace("Z", "+00:00") if text.endswith("Z") else text)
        return (text, moment) if moment.tzinfo else None
    except ValueError:
        return None


def _details(event: dict[str, Any], place: str, join: str) -> EventDetails | None:
    """What Today's agenda needs. None when the entry has no readable start (a cancelled entry from an incremental
    read often has only its id and status), because a time the host can't read would make it refuse the whole read.
    `singleEvents` expands a series, so `repeats` stays empty."""
    start_part = event.get("start") if isinstance(event.get("start"), dict) else {}
    all_day = bool(start_part.get("date")) and not start_part.get("dateTime")
    first = _stated(start_part, all_day)
    if first is None:
        return None
    last = _stated(event.get("end"), all_day)
    if last is not None and last[1] < first[1]:
        last = None
    return EventDetails(
        start=first[0],
        end=last[0] if last else None,
        all_day=all_day,
        where=place or join or None,
        cancelled=event.get("status") == "cancelled",
    )


def event_item(event: dict[str, Any], max_description_chars: int) -> SourceItem:
    """One Google event as a source item. A cancelled event may be little more than its id and status."""
    status = event.get("status")
    summary = str(event.get("summary") or "").strip()
    organizer = event.get("organizer") or {}
    attendees = []
    for attendee in event.get("attendees") or []:
        answer = str(attendee.get("responseStatus") or "needsAction")
        kind = " (optional)" if attendee.get("optional") else ""
        attendees.append(f"- {person(attendee)}{kind}: {_ANSWERS.get(answer, answer)}")
    description = _description(event.get("description"), max_description_chars)
    when, place, join = _when(event), str(event.get("location") or "").strip(), _meeting(event)
    lines = [
        f"Subject: {summary}" if summary else "",
        f"When: {when}" if when else "",
        "All day: yes" if (event.get("start") or {}).get("date") else "",
        {"cancelled": "Status: Cancelled", "tentative": "Status: Tentative"}.get(str(status), ""),
        f"Where: {place}" if place else "",
        f"Organizer: {person(organizer)}" if person(organizer) else "",
        "Attendees:" if attendees else "",
        *attendees,
        f"Online meeting: {join}" if join else "",
        "Recurring: an occurrence of a series" if event.get("recurringEventId") else "",
        "Description:" if description else "",
        description,
    ]
    return SourceItem(
        key=str(event["id"]),
        title=summary or ("(cancelled event)" if status == "cancelled" else "(no title)"),
        text="\n".join(line for line in lines if line),
        author=organizer.get("email") or None,
        changed_at=event.get("updated"),
        link=event.get("htmlLink"),
        event=_details(event, place, join),
    )


def _window(settings: CalendarSettings) -> dict[str, str]:
    today = _today()
    return {
        "timeMin": stamp(today - timedelta(days=settings.days_back)),
        "timeMax": stamp(today + timedelta(days=settings.days_ahead)),
    }


def _outside(event: dict[str, Any], window: dict[str, str]) -> bool:
    """Whether a change falls outside the window. A cancelled event is never left out: it may be one we have, and
    its entry often has no times. An event that overlaps the window is inside, as a full read would count it."""
    if event.get("status") == "cancelled":
        return False
    start, end = _moment(event.get("start")), _moment(event.get("end")) or _moment(event.get("start"))
    first, last = datetime.fromisoformat(window["timeMin"]), datetime.fromisoformat(window["timeMax"])
    if start is None or end is None:
        return False
    return start >= last or (end <= first and start < first)


def _feeds(
    reader: Reader, settings: CalendarSettings, window: dict[str, str], state: dict[str, Any]
) -> tuple[list[Feed], dict[str, str]]:
    """The calendars to read, and the name -> id list to remember."""
    names = [name.strip() for name in settings.calendars if name.strip()]
    if not names:
        return [_feed("primary", window)], {}
    listed = {  # id -> the names it goes by, best first
        str(c["id"]): (str(c.get("summaryOverride") or ""), str(c.get("summary") or ""), str(c["id"]))
        for c in reader.listing(
            f"{CALENDAR}/users/me/calendarList",
            {"fields": "items(id,summary,summaryOverride),nextPageToken"},
            counted=False,
        )
        if c.get("id")
    }
    remembered = state.get("calendars") or {}
    found: dict[str, str] = {}
    for name in names:
        key = name.casefold()
        calendar_id = find_by_name(name, listed, remembered.get(key))
        if not calendar_id:
            raise ConnectorError("not_found", f"No calendar named {name}")
        found[key] = calendar_id
    feeds = {calendar_id: _feed(calendar_id, window) for calendar_id in found.values()}
    return list(feeds.values()), found


def _feed(calendar_id: str, window: dict[str, str]) -> Feed:
    return Feed(
        calendar_id,
        f"{CALENDAR}/calendars/{quote(calendar_id, safe='')}/events",
        base=BASE_QUERY,
        full={**BASE_QUERY, **window},
    )


def read_calendar(settings: CalendarSettings, state: dict[str, Any], context: Any) -> Poll:
    """Read the events in the window. Returns what was taken this time; `state` keeps where each calendar stands."""
    window = _window(settings)
    reader = Reader(
        context,
        max_pages=settings.max_pages_per_read,
        max_items=settings.max_events_per_read,
        throttle_wait=settings.throttle_wait_seconds,
        convert=lambda event, feed: event_item(event, settings.max_description_chars),
        skip=lambda event: _outside(event, window),
        api_off=CALENDAR_API_OFF,
    )
    require_scope(context, SIGN_IN, CALENDAR_SCOPE, CALENDAR_NOT_ALLOWED)
    same_window = state.get("window") == window  # a moved or changed window drops the sync tokens
    saved = (state.get("feeds") or {}) if same_window else {}
    feeds, remembered = _feeds(reader, settings, window, state)
    resume = state.get("resume") if same_window else None
    start = next((i for i, feed in enumerate(feeds) if feed.key == resume), 0)
    keep = {feed.key: saved.get(feed.key, {}) for feed in feeds}
    stopped = None
    for feed in feeds[start:] + feeds[:start]:
        if reader.full:
            stopped = stopped or feed.key
            break
        keep[feed.key], finished = reader.read_feed(feed, keep[feed.key])
        if not finished:
            stopped = feed.key
            break
    new_state = {"window": window, "calendars": remembered, "feeds": keep, "resume": stopped}
    return Poll(items=list(reader.items.values()), state=new_state, complete=False)


def _older_pages(
    settings: CalendarSettings, since: date, before: date, context: Any, max_items: int, *, count: bool
) -> tuple[Reader, list[list[dict[str, Any]]]]:
    """For each chosen calendar, the events dated from `since` up to, not including, `before` (UTC days), oldest
    first as Google gives them: every page that fits the page budget, or (to count) one page."""
    reader = Reader(
        context,
        max_pages=settings.max_pages_per_read,
        max_items=max_items,
        throttle_wait=settings.throttle_wait_seconds,
        api_off=CALENDAR_API_OFF,
    )
    require_scope(context, SIGN_IN, CALENDAR_SCOPE, CALENDAR_NOT_ALLOWED)
    window = {"timeMin": stamp(since), "timeMax": stamp(before)}
    feeds, _ = _feeds(reader, settings, window, {})
    found = []
    for feed in feeds:
        query = {**BASE_QUERY, **window, "orderBy": "startTime"}
        if count:
            query["maxResults"] = str(min(max_items, 2500))
        events: list[dict[str, Any]] = []
        page = None
        while reader.pages < reader.max_pages:
            body = reader.fetch(feed.url, {**query, "pageToken": page} if page else query)
            events += [e for e in body.get("items", []) if isinstance(e, dict) and e.get("id")]
            page = body.get("nextPageToken")
            if not page or count:
                break
        found.append(events)
    return reader, found


def older_calendar(
    settings: CalendarSettings, since: date, before: date, max_items: int, context: Any
) -> list[SourceItem]:
    """The newest `max_items` events dated from `since` up to, not including, `before`, as a read hands them in.
    Google lists oldest first, so the newest are taken from what the page budget reached."""
    _, found = _older_pages(settings, since, before, context, max_items, count=False)
    floor = datetime.min.replace(tzinfo=UTC)
    events = {str(e["id"]): e for events in found for e in events}.values()
    newest = sorted(events, key=lambda e: _moment(e.get("start")) or floor, reverse=True)[:max_items]
    return [event_item(event, settings.max_description_chars) for event in newest]


def older_count(settings: CalendarSettings, since: date, before: date, max_items: int, context: Any) -> int:
    """How many events there are in the days asked for, at most `max_items`: one page of each calendar is counted."""
    _, found = _older_pages(settings, since, before, context, max_items, count=True)
    return min(len({str(e["id"]) for events in found for e in events}), max_items)
