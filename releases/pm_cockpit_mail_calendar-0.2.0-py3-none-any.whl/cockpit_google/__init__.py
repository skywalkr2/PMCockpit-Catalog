"""Reads a person's Gmail and Google Calendar, signed in as the person. Read-only."""

from pathlib import Path

from engine.plugin_api import Registrar, Settings

from cockpit_mail_calendar_common import shipped_app
from cockpit_mail_calendar_common.triage import answers_only, automatic_replies, mailing_lists

from .calendar import CalendarSettings, older_calendar, read_calendar
from .calendar import older_count as older_calendar_count
from .channels import (
    CALENDAR_CHANNEL,
    MAIL_CHANNEL,
    calendar_status,
    folders,
    mail_status,
    send_calendar,
    send_mail,
    undo_calendar,
    undo_mail,
)
from .mail import MailSettings, older_mail, read_mail
from .mail import older_count as older_mail_count
from .sign_in import (
    ACTING_SCOPES,
    ALLOWS,
    DEFAULT_APP_NOTE,
    DEFAULT_REDIRECTS,
    OWN_APP_STEPS,
    REVOKE_URL,
    SCOPES,
    SOURCES,
    account,
)


class Config(Settings):
    pass


def register(registrar: Registrar) -> None:
    """Register the Google sign-in (with the publisher's app registration, when the package ships one), the calendar
    and mail connectors and the triage rule kinds."""
    app = shipped_app(Path(__file__).parent)
    shipped = "client_id" in app and "client_secret" in app  # a client secret is never used without its id
    registrar.sign_in(
        "google/account",
        label="Google account",
        authorize_url="https://accounts.google.com/o/oauth2/v2/auth",
        token_url="https://oauth2.googleapis.com/token",
        scopes=SCOPES,
        client_id="client-id",
        client_secret="client-secret",
        params={"access_type": "offline", "prompt": "select_account consent"},
        allows=ALLOWS,
        account=account,
        revoke_url=REVOKE_URL,
        default_client_id=app["client_id"] if shipped else None,
        default_client_secret=app["client_secret"] if shipped else None,
        default_app_note=DEFAULT_APP_NOTE,
        default_redirects=DEFAULT_REDIRECTS if shipped else (),
        own_app_steps=OWN_APP_STEPS,
        sources=SOURCES,
        acting_scopes=ACTING_SCOPES,
    )
    registrar.connector(
        "google/calendar",
        label="Google Calendar",
        settings=CalendarSettings,
        poll=read_calendar,
        reads="calendar",
        older=older_calendar,
        older_count=older_calendar_count,
    )
    registrar.connector(
        "google/mail",
        label="Gmail",
        settings=MailSettings,
        poll=read_mail,
        reads="mail",
        older=older_mail,
        older_count=older_mail_count,
    )
    registrar.channel(
        MAIL_CHANNEL,
        label="Gmail",
        kinds=["message", "mailbox"],
        send=send_mail,
        folders=folders,
        status=mail_status,
        undo=undo_mail,
        actions={
            "message": ["send", "reply", "reply_all", "forward"],
            "mailbox": ["archive", "move", "label", "mark_read"],
        },
        accounts=["google/account"],
    )
    registrar.channel(
        CALENDAR_CHANNEL,
        label="Google Calendar",
        kinds=["calendar"],
        send=send_calendar,
        status=calendar_status,
        undo=undo_calendar,
        actions={"calendar": ["create", "move", "cancel", "answer"]},
        accounts=["google/account"],
    )
    registrar.triage_matcher("google/mailing-lists", match=mailing_lists)
    registrar.triage_matcher("google/automatic-replies", match=automatic_replies)
    registrar.triage_matcher("google/answers-only", match=answers_only)
