"""The Outlook mail connector: messages in the folders the person names, read through Microsoft Graph. Read-only.

With no folder named, it reads the well-known inbox. Each folder is read with a message delta: the first read takes
the last `days_back` days, and later reads take only what changed. Messages the delta says are gone (deleted, or
moved out of the folder) are handed in as removed. A read is bounded by pages and messages; what it didn't reach
waits in `state` for the next read. Only GET requests are made.
"""

from __future__ import annotations

import base64
import binascii
from datetime import UTC, date, datetime, timedelta
from typing import Any
from urllib.parse import quote

from engine.plugin_api import ConnectorError, ItemFile, MessageDetails, Poll, SourceItem
from pydantic import BaseModel, ConfigDict, Field

from cockpit_mail_calendar_common import require_scope
from cockpit_mail_calendar_common.triage import bulk, sent_as

from .graph import GRAPH, PAGE_SIZE, SIGN_IN, Feed, PageIncomplete, Reader, body_text, find_by_name, person, stamp
from .sign_in import MAIL_NOT_ALLOWED, MAIL_SCOPE

ATTACHMENT_PAGE_SIZE = 10
PREFER = f'odata.maxpagesize={PAGE_SIZE}, outlook.body-content-type="text", IdType="ImmutableId"'
FOLDERS = f"{GRAPH}/me/mailFolders"
FILE_ATTACHMENT = "#microsoft.graph.fileAttachment"
WELL_KNOWN = {"inbox", "archive", "sentitems", "drafts", "deleteditems", "junkemail"}
_FOLDER_QUERY = {"$select": "id,displayName", "$top": "100"}
_SELECT = (
    "id,subject,from,toRecipients,ccRecipients,receivedDateTime,lastModifiedDateTime,"
    "hasAttachments,body,webLink,isDraft,isRead,internetMessageHeaders,categories,inferenceClassification"
)


class MailSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    folders: list[str] = Field(
        default_factory=list,
        description=(
            "The folders to read: a well-known name (inbox, archive, sentitems), a folder's name, or a path "
            "such as Inbox/Projects. Empty means your inbox."
        ),
    )
    days_back: int = Field(
        14, ge=0, le=365, description="How many days back the first read goes. Later reads take only what changed."
    )
    max_messages_per_read: int = Field(
        200, ge=1, le=5000, description="The most messages one read hands in. The rest wait for the next read."
    )
    max_pages_per_read: int = Field(
        20,
        ge=1,
        le=200,
        description="The most pages one read asks the service for, folder lookups included. The rest wait.",
    )
    max_body_chars: int = Field(
        8000, ge=0, le=100000, description="How much of a message's text is kept. 0 keeps none."
    )
    max_link_chars: int = Field(
        60,
        ge=0,
        le=1000,
        description=(
            "How long a link's address may be in a message's text: it is shortened to its host and path and cut here. "
            "0 leaves link addresses out."
        ),
    )
    read_attachments: bool = Field(
        True,
        description=(
            "Whether to read the files attached to new messages, so their text is part of the message. "
            "Needs the attachment lookup, which costs one request for each message with attachments, and one more "
            "for each file."
        ),
    )
    max_attachments_per_message: int = Field(
        5, ge=0, le=50, description="The most attached files read for one message. The rest stay listed by name."
    )
    max_attachment_bytes: int = Field(
        5_000_000,
        ge=0,
        le=100_000_000,
        description="The largest attached file that is read, in bytes. Larger ones stay listed by name.",
    )
    max_attachment_requests_per_read: int = Field(
        100,
        ge=0,
        le=5000,
        description=(
            "The most requests one read makes for attachments (the list of a message's files, and each file). "
            "They are counted apart from the pages. When they run out, later messages wait for the next read."
        ),
    )
    attachment_names: bool = Field(
        True,
        description="Whether to list attachment names. This costs one request for each message with attachments.",
    )
    max_attachment_lookups_per_read: int = Field(
        50,
        ge=0,
        le=1000,
        description="The most messages per read whose attachment names are looked up. The rest say names weren't read.",
    )


def _today() -> date:
    return datetime.now(UTC).date()


def _received(value: Any) -> str:
    """A Graph UTC time such as 2026-10-12T09:14:00Z as `2026-10-12 09:14 UTC`, or "" when it isn't one."""
    try:
        moment = datetime.fromisoformat(str(value))
    except ValueError:
        return ""
    moment = moment.replace(tzinfo=UTC) if moment.tzinfo is None else moment.astimezone(UTC)
    return f"{moment:%Y-%m-%d %H:%M} UTC"


def _received_at(value: Any) -> str | None:
    """A Graph UTC time as ISO 8601 with `Z`, or None when it isn't one."""
    try:
        moment = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    moment = moment.replace(tzinfo=UTC) if moment.tzinfo is None else moment.astimezone(UTC)
    return f"{moment:%Y-%m-%dT%H:%M:%S}Z"


def _prefer(settings: MailSettings) -> str:
    """The Prefer header: a smaller page when attachments are read, so a page's files fit the request budget."""
    if settings.read_attachments and settings.attachment_names:
        return PREFER.replace(f"maxpagesize={PAGE_SIZE}", f"maxpagesize={ATTACHMENT_PAGE_SIZE}", 1)
    return PREFER


def _people(recipients: Any) -> str:
    return ", ".join(name for name in (person(r.get("emailAddress")) for r in recipients or []) if name)


class _Messages:
    """Turns messages into items. Looking up attachments makes requests, which have a budget of their own."""

    def __init__(self, settings: MailSettings, own: str | None = None):
        self.settings = settings
        self.own = own  # the signed-in account's address, left out of the participants
        self.reader: Reader | None = None  # set once the read exists
        self.lookups = 0
        self.requests = 0  # attachment requests made in this read

    def _spent(self) -> bool:
        return self.requests >= self.settings.max_attachment_requests_per_read

    def _stop(self) -> None:
        """The attachments can't all be read in this read. A message always carries all its files, so its page waits
        for the next read; only when nothing has been taken yet (the read's first page) it goes ahead with what it
        has, so a source always moves on."""
        if self.reader is not None and self.reader.items:
            raise PageIncomplete

    def attachments(self, message: dict[str, Any]) -> tuple[str, tuple[ItemFile, ...]]:
        """The attachment names ("yes (names not read)" when they weren't looked up, "" when there are none) and the
        files read, within the limits."""
        if not message.get("hasAttachments"):
            return "", ()
        settings, reader = self.settings, self.reader
        if reader and settings.attachment_names:
            if self.lookups < settings.max_attachment_lookups_per_read and not self._spent():
                self.lookups += 1
                self.requests += 1
                message_id = quote(str(message["id"]), safe="")
                try:
                    body = reader.fetch(
                        f"{GRAPH}/me/messages/{message_id}/attachments",
                        {"$select": "name,contentType,size,isInline"},
                        counted=False,
                    )
                except ConnectorError as err:
                    if err.kind != "not_found":  # the message moved or went since its page: names weren't read
                        raise
                else:
                    listed = [a for a in body.get("value", []) if isinstance(a, dict) and not a.get("isInline")]
                    names = [str(a.get("name") or "").strip() for a in listed]
                    return ", ".join(name for name in names if name), self._files(message_id, listed)
            elif settings.read_attachments:
                self._stop()
        return "yes (names not read)", ()

    def _files(self, quoted_id: str, listed: list[dict[str, Any]]) -> tuple[ItemFile, ...]:
        settings, reader = self.settings, self.reader
        if not settings.read_attachments or reader is None or not listed:
            return ()
        wanted = [a for a in listed if a.get("@odata.type") == FILE_ATTACHMENT and a.get("id")]
        files: list[ItemFile] = []
        reading = [
            a
            for a in wanted[: settings.max_attachments_per_message]
            if not (isinstance(a.get("size"), int) and a["size"] > settings.max_attachment_bytes)
        ]
        if len(reading) > settings.max_attachment_requests_per_read - self.requests:
            self._stop()  # they would not all fit: wait for a read with the whole budget (unless it is the first)
        for attachment in reading:
            if self._spent():
                self._stop()
                break
            self.requests += 1
            try:
                body = reader.fetch(
                    f"{GRAPH}/me/messages/{quoted_id}/attachments/{quote(str(attachment['id']), safe='')}",
                    counted=False,
                )
            except ConnectorError as err:
                if err.kind != "not_found":
                    raise
                continue
            try:
                raw = base64.b64decode(str(body.get("contentBytes") or ""))
            except (binascii.Error, ValueError):
                continue
            if raw and len(raw) <= settings.max_attachment_bytes:
                files.append(
                    ItemFile(str(attachment.get("name") or "").strip(), str(attachment.get("contentType") or ""), raw)
                )
        return tuple(files)

    def item(self, message: dict[str, Any], feed: Feed) -> SourceItem:
        """One Graph message as a source item."""
        subject = str(message.get("subject") or "").strip()
        sender = (message.get("from") or {}).get("emailAddress")
        sent = person(sender)
        to, cc = _people(message.get("toRecipients")), _people(message.get("ccRecipients"))
        date_ = _received(message.get("receivedDateTime"))
        attachments, files = self.attachments(message)
        head = [
            f"From: {sent}" if sent else "",
            f"To: {to}" if to else "",
            f"Cc: {cc}" if cc else "",
            f"Date: {date_}" if date_ else "",
            f"Subject: {subject}" if subject else "",
            f"Folder: {feed.label}" if feed.label else "",
            f"Attachments: {attachments}" if attachments else "",
            *sent_as(message.get("internetMessageHeaders")),
        ]
        body = body_text(message.get("body"), self.settings.max_body_chars, self.settings.max_link_chars)
        return SourceItem(
            key=str(message["id"]),
            title=subject or "(no subject)",
            text="\n".join(line for line in head if line) + (f"\n\n{body}" if body else ""),
            author=((sender or {}).get("address") if isinstance(sender, dict) else None) or None,
            changed_at=message.get("lastModifiedDateTime"),
            link=message.get("webLink"),
            files=files,
            # Opened or not is a detail only: it never goes in the text, or opening a message would hand it in again.
            message=MessageDetails(
                sender=sent or None,
                received=_received_at(message.get("receivedDateTime")),
                unread=None if "isRead" not in message else not message["isRead"],
                bulk=bulk(message.get("internetMessageHeaders")),
                categories=_categories(message),
                participants=_participants(message, sender, self.own),
            ),
        )


def _participants(message: dict[str, Any], sender: Any, own: str | None) -> tuple[str, ...]:
    """The To and Cc people, in order, each once, without the sender and the signed-in account, as `Name <address>`."""
    left_out = {str((sender or {}).get("address") or "").casefold()} if isinstance(sender, dict) else set()
    if own:
        left_out.add(own.strip().casefold())
    left_out.discard("")
    found: dict[str, str] = {}
    for recipient in [*(message.get("toRecipients") or []), *(message.get("ccRecipients") or [])]:
        address = recipient.get("emailAddress") if isinstance(recipient, dict) else None
        shown = person(address)
        key = str((address or {}).get("address") or "").casefold() or shown.casefold()
        if shown and key not in left_out:
            found.setdefault(key, shown)
    return tuple(found.values())


def _categories(message: dict[str, Any]) -> tuple[str, ...]:
    """The message's own categories, then Focused or Other when Graph says: trimmed, in lower case, each once."""
    own = message.get("categories")
    found = [str(name).strip().casefold() for name in (own if isinstance(own, list) else [])]
    found.append(str(message.get("inferenceClassification") or "").strip().casefold())
    return tuple(dict.fromkeys(name for name in found if name))


def _folder_by_id(reader: Reader, folder: str) -> str | None:
    """The id of the folder at `/me/mailFolders/{folder}` (a well-known name or an id), None when it isn't there."""
    try:
        body = reader.fetch(f"{FOLDERS}/{quote(folder, safe='')}", {"$select": "id,displayName"})
    except ConnectorError as err:
        if err.status == 404:  # the web client raises not_found on a 404 and keeps the status
            return None
        raise
    return str(body["id"]) if body.get("id") else None


def _folder_id(reader: Reader, name: str, remembered_id: str | None) -> str | None:
    """The id of the folder the person named: a well-known name, the remembered id if it still answers, or the
    path of display names walked down from the top. None when none of them leads to a folder."""
    parts = [part.strip() for part in name.split("/") if part.strip()]
    if len(parts) == 1 and parts[0].casefold() in WELL_KNOWN:
        return _folder_by_id(reader, parts[0].casefold())
    if remembered_id and _folder_by_id(reader, remembered_id):
        return remembered_id  # still there, maybe under another name
    parent = None
    for part in parts:
        url = FOLDERS if parent is None else f"{FOLDERS}/{quote(parent, safe='')}/childFolders"
        listed = {
            str(f["id"]): str(f.get("displayName") or "")
            for f in reader.listing(url, dict(_FOLDER_QUERY), counted=True)
            if f.get("id")
        }
        parent = find_by_name(part, listed)
        if parent is None:
            return None
    return parent


def _feeds(reader: Reader, names: list[str], since: str, state: dict[str, Any]) -> tuple[list[Feed], dict[str, str]]:
    """The folders to read, and the name -> id list to remember."""
    remembered = state.get("folders") or {}
    saved = state.get("feeds") or {}
    found: dict[str, str] = {}
    feeds: dict[str, Feed] = {}
    for name in names:
        key = name.casefold()
        known = remembered.get(key)
        if known and (saved.get(known) or {}).get("next"):
            folder_id: str | None = known  # part way through a folder: carry on from the saved link
        else:
            folder_id = _folder_id(reader, name, known)
        if not folder_id:
            raise ConnectorError("not_found", f"No mail folder named {name}")
        found[key] = folder_id
        feeds.setdefault(
            folder_id,
            Feed(
                folder_id,
                f"{FOLDERS}/{quote(folder_id, safe='')}/messages/delta",
                delta=True,
                params={"$select": _SELECT, "$filter": f"receivedDateTime ge {since}"},
                label=name,
            ),
        )
    return list(feeds.values()), found


def read_mail(settings: MailSettings, state: dict[str, Any], context: Any) -> Poll:
    """Read the messages in the named folders. Returns what was taken this time; `state` keeps where each stands."""
    names = [name.strip() for name in settings.folders if name.strip()]
    if not names:
        names = ["inbox"]  # no choice made: the well-known inbox, exactly as if it were named
    messages = _Messages(settings, getattr(context, "account", None))
    reader = Reader(
        context,
        prefer=_prefer(settings),
        max_pages=settings.max_pages_per_read,
        max_items=settings.max_messages_per_read,
        convert=messages.item,
        skip=lambda message: bool(message.get("isDraft")),
    )
    messages.reader = reader
    require_scope(context, SIGN_IN, MAIL_SCOPE, MAIL_NOT_ALLOWED)
    since = stamp(_today() - timedelta(days=settings.days_back))
    feeds, remembered = _feeds(reader, names, since, state)
    if reader.pages >= settings.max_pages_per_read:
        raise ConnectorError(
            "outage", "Microsoft: the page limit for one read is used up by folder lookups; raise max_pages_per_read"
        )
    saved = state.get("feeds") or {}
    start = next((i for i, feed in enumerate(feeds) if feed.key == state.get("resume")), 0)
    keep = {feed.key: saved.get(feed.key, {}) for feed in feeds}
    stopped = None
    for feed in feeds[start:] + feeds[:start]:
        if reader.full:
            stopped = stopped or feed.key
            break
        keep[feed.key], finished = reader.read_feed(feed, keep[feed.key])
        if not finished:
            stopped = feed.key
            break
    new_state = {"folders": remembered, "feeds": keep, "resume": stopped}
    return Poll(items=list(reader.items.values()), state=new_state, complete=False, removed=list(reader.removed))


def _older_folders(settings: MailSettings, context: Any, max_items: int) -> tuple[Reader, _Messages, list[Feed]]:
    names = [name.strip() for name in settings.folders if name.strip()] or ["inbox"]
    messages = _Messages(settings, getattr(context, "account", None))
    reader = Reader(
        context,
        prefer=_prefer(settings),
        max_pages=settings.max_pages_per_read,
        max_items=max_items,
        convert=messages.item,
        skip=lambda message: bool(message.get("isDraft")),
    )
    messages.reader = reader
    require_scope(context, SIGN_IN, MAIL_SCOPE, MAIL_NOT_ALLOWED)
    found: dict[str, Feed] = {}
    for name in names:
        folder_id = _folder_id(reader, name, None)
        if not folder_id:
            raise ConnectorError("not_found", f"No mail folder named {name}")
        found.setdefault(
            folder_id, Feed(folder_id, f"{FOLDERS}/{quote(folder_id, safe='')}/messages", delta=False, label=name)
        )
    if reader.pages >= reader.max_pages:
        raise ConnectorError(
            "outage", "Microsoft: the page limit for one read is used up by folder lookups; raise max_pages_per_read"
        )
    return reader, messages, list(found.values())


def _window(since: date, before: date) -> str:
    return f"receivedDateTime ge {stamp(since)} and receivedDateTime lt {stamp(before)}"


def older_mail(settings: MailSettings, since: date, before: date, max_items: int, context: Any) -> list[SourceItem]:
    """The newest `max_items` messages dated from `since` up to, not including, `before`, as a read hands them in."""
    reader, messages, feeds = _older_folders(settings, context, max_items)
    found: dict[str, tuple[dict[str, Any], Feed]] = {}
    for feed in feeds:
        url: str | None = feed.url
        params: dict[str, str] | None = {
            "$select": _SELECT,
            "$filter": _window(since, before),
            "$orderby": "receivedDateTime desc",
            "$top": str(min(max_items, 1000)),
        }
        taken = 0
        while url and reader.pages < reader.max_pages and taken < max_items:
            body = reader.fetch(url, params)
            for message in body.get("value", []):
                if isinstance(message, dict) and message.get("id") and not message.get("isDraft") and taken < max_items:
                    found.setdefault(str(message["id"]), (message, feed))
                    taken += 1
            url, params = body.get("@odata.nextLink"), None
    newest = sorted(found.values(), key=lambda found_in: str(found_in[0].get("receivedDateTime") or ""), reverse=True)
    items = []
    for message, feed in newest[:max_items]:
        try:
            items.append(messages.item(message, feed))
        except PageIncomplete:  # the page budget is used up: the messages so far are the answer
            break
    return items


def older_count(settings: MailSettings, since: date, before: date, max_items: int, context: Any) -> int:
    """How many messages there are dated from `since` up to, not including, `before`, at most `max_items`: the
    service counts them in each folder, and nothing is read."""
    reader, _, feeds = _older_folders(settings, context, max_items)
    reader.headers["ConsistencyLevel"] = "eventual"
    total = 0
    for feed in feeds:
        body = reader.fetch(
            feed.url, {"$filter": _window(since, before), "$count": "true", "$top": "1", "$select": "id"}
        )
        count = body.get("@odata.count")
        total += count if isinstance(count, int) else 0
    return min(total, max_items)
