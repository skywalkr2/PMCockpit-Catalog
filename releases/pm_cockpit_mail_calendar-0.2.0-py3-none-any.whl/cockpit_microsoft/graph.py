"""What the Outlook connectors share: a bounded reader of Microsoft Graph feeds (a delta or a plain listing), with the
token and headers, paging, the page and item caps, resume, the once-per-read restart of an expired delta, and name
matching against a listed collection. The calendar and mail connectors keep only what is their own."""

from __future__ import annotations

from collections.abc import Callable
from datetime import date
from typing import Any

from engine.plugin_api import ConnectorError, SourceItem

from cockpit_mail_calendar_common import clip, html_to_text, looks_like_html, service_error

SIGN_IN = "microsoft/account"
GRAPH = "https://graph.microsoft.com/v1.0"
PAGE_SIZE = 50


def stamp(day: date) -> str:
    """The start of a day in UTC, as Graph takes it in a query."""
    return f"{day.isoformat()}T00:00:00Z"


def person(address: Any) -> str:
    """A Graph `emailAddress` as `Name <address>`, or whichever of the two there is."""
    address = address if isinstance(address, dict) else {}
    name, email = str(address.get("name") or ""), str(address.get("address") or "")
    if name and email and name != email:
        return f"{name} <{email}>"
    return email or name


def body_text(body: Any, max_chars: int, max_link_chars: int | None = None) -> str:
    """The text of a Graph `body` (`contentType` and `content`): HTML, and text that has HTML tags in it, is turned
    into text (with link addresses shortened when `max_link_chars` is given), and the result is cut."""
    body = body if isinstance(body, dict) else {}
    content = str(body.get("content") or "")
    if str(body.get("contentType") or "").casefold() == "html" or looks_like_html(content):
        return html_to_text(content, max_chars, max_link_chars)
    return clip(content.replace("\r\n", "\n").replace("\r", "\n").strip(), max_chars)


def find_by_name(name: str, listed: dict[str, str], remembered_id: str | None = None) -> str | None:
    """The id of the entry called `name` (ignoring case) in `listed` (id -> name). When no entry has that name, the
    remembered id is kept if it is still listed, so a renamed entry is still read."""
    by_name = {title.casefold(): item_id for item_id, title in listed.items()}
    found = by_name.get(name.casefold())
    return found or (remembered_id if remembered_id in listed else None)


class PageIncomplete(Exception):
    """Raised by a `convert` that can't finish an entry in this read (the page budget ran out): the page it was on
    is left whole for the next read."""


class Feed:
    """One place to read: where its first request goes (and with what query), and whether it answers with a delta."""

    def __init__(self, key: str, url: str, *, delta: bool, params: dict[str, str] | None = None, label: str = ""):
        self.key, self.url, self.delta, self.params, self.label = key, url, delta, params, label


class Reader:
    """One read: the requests it made, the items it took, and where it stopped.

    `convert` turns a Graph entry into an item; `skip` says which entries to leave out (entries without an id are
    always left out). An entry marked `@removed` is a deleted one (or one moved out of the folder): its id goes to
    `removed`. A page is taken whole or left for the next read.
    """

    def __init__(
        self,
        context: Any,
        *,
        prefer: str,
        max_pages: int,
        max_items: int,
        convert: Callable[[dict[str, Any], Feed], SourceItem],
        skip: Callable[[dict[str, Any]], bool] | None = None,
    ):
        token = context.access_token(SIGN_IN)  # a withdrawn sign-in raises auth, which propagates
        self.web = context.web
        self.headers = {"Authorization": f"Bearer {token}", "Prefer": prefer}
        self.max_pages, self.max_items = max_pages, max_items
        self.convert, self.skip = convert, skip
        self.items: dict[str, SourceItem] = {}
        self.removed: dict[str, None] = {}  # the ids Graph says are gone, in order, each once
        self.origin: dict[str, str] = {}  # item key -> the key of the feed it came from
        self.pages = 0
        self.restarted = False

    @property
    def full(self) -> bool:
        """Whether this read has used its pages or filled its items."""
        return self.pages >= self.max_pages or len(self.items) >= self.max_items

    def get(self, url: str, params: dict[str, str] | None = None) -> tuple[int, Any]:
        """One GET, not counted. Returns the status and the decoded body (None when it isn't JSON)."""
        response = self.web.get(url, params=params, headers=self.headers)
        try:
            body = response.json()
        except ValueError:
            body = None
        return response.status, body

    def fetch(self, url: str, params: dict[str, str] | None = None, *, counted: bool = True) -> dict[str, Any]:
        """One GET that must succeed with a JSON object. A counted request is one of this read's pages."""
        if counted:
            if self.pages >= self.max_pages:
                raise ConnectorError(
                    "outage", "Microsoft: the page limit for one read ran out before the lookups were done"
                )
            self.pages += 1
        status, body = self.get(url, params)
        if status >= 300:
            raise service_error(status, body, "Microsoft")
        if not isinstance(body, dict):
            raise ConnectorError("outage", "Microsoft: the answer wasn't readable")
        return body

    def _gone(self, key: str, feed: Feed) -> None:
        """Note that Graph says `key` is gone. An item taken earlier from this feed is dropped. One taken from another
        feed stays: a message moved from one chosen folder to another is gone from the first and new in the second."""
        if key in self.items:
            if self.origin.get(key) != feed.key:
                return
            del self.items[key]
        self.removed[key] = None

    def listing(self, url: str, params: dict[str, str] | None, *, counted: bool) -> list[dict[str, Any]]:
        """Every entry of a collection, following next links, in at most `max_pages` requests."""
        entries: list[dict[str, Any]] = []
        for _ in range(self.max_pages):
            body = self.fetch(url, params, counted=counted)
            entries.extend(entry for entry in body.get("value", []) if isinstance(entry, dict))
            url, params = body.get("@odata.nextLink"), None
            if not url:
                break
        return entries

    def read_feed(
        self, feed: Feed, saved: dict[str, str], seen: list[str] | None = None
    ) -> tuple[dict[str, str], bool]:
        """Read one feed from its saved link. Returns the state to keep for it and whether it was finished.

        `seen`, when given, collects the id of every entry the feed lists (it is emptied when the feed starts again)."""
        link = saved.get("next") or saved.get("delta")
        url, params = (link, None) if link else (feed.url, feed.params)
        took = False  # a page of this read was taken, so the saved link is behind
        while True:
            if self.pages >= self.max_pages:
                return ({"next": url} if took else saved), False
            self.pages += 1
            status, body = self.get(url, params)
            if status == 410 and params is None and not self.restarted:
                # The saved link expired: start this feed again, once per read.
                self.restarted = True
                saved, took = {}, False
                url, params = feed.url, feed.params
                if seen is not None:
                    seen.clear()
                continue
            if status >= 300:
                raise service_error(status, body, "Microsoft")
            if not isinstance(body, dict):
                raise ConnectorError("outage", "Microsoft: the answer wasn't readable")
            listed = [e for e in body.get("value", []) if isinstance(e, dict) and e.get("id")]
            entries = [e for e in listed if "@removed" not in e and not (self.skip and self.skip(e))]
            if self.items and len(self.items.keys() | {str(e["id"]) for e in entries}) > self.max_items:
                return ({"next": url} if took else saved), False  # this page waits for the next read
            try:
                converted = [self.convert(entry, feed) for entry in entries]
            except PageIncomplete:
                return ({"next": url} if took else saved), False  # this page waits for the next read
            for entry in listed:
                key = str(entry["id"])
                if "@removed" in entry:
                    self._gone(key, feed)
            for item in converted:
                self.items[item.key] = item
                self.origin[item.key] = feed.key
                self.removed.pop(item.key, None)
            if seen is not None:
                seen.extend(str(e["id"]) for e in listed)
            took = True
            if body.get("@odata.nextLink"):
                url, params = body["@odata.nextLink"], None
                if len(self.items) >= self.max_items:
                    return {"next": url}, False
            elif body.get("@odata.deltaLink") and feed.delta:
                return {"delta": body["@odata.deltaLink"]}, True
            else:
                return {}, True
