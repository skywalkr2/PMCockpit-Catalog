"""What the Microsoft sign-in asks, what it tells the person it asks, and how it names the signed-in account."""

from __future__ import annotations

from typing import Any

from engine.plugin_api import ConnectorError

from cockpit_mail_calendar_common import service_error

from .graph import GRAPH, SIGN_IN, person

MAIL_SCOPE = "https://graph.microsoft.com/Mail.Read"
CALENDAR_SCOPE = "https://graph.microsoft.com/Calendars.Read"
#: Asked for only when the person turns acting on: changing and sending mail, and writing events.
ACTING_SCOPES = (
    "https://graph.microsoft.com/Mail.ReadWrite",
    "https://graph.microsoft.com/Mail.Send",
    "https://graph.microsoft.com/Calendars.ReadWrite",
)
SCOPES = (MAIL_SCOPE, CALENDAR_SCOPE, "https://graph.microsoft.com/User.Read", "offline_access")
#: What the person is told before they leave for Microsoft's page. Each line is at most 80 characters.
ALLOWS = (
    "Read your mail (it never deletes anything)",
    "Read your calendars",
    "See your name and email address, to show which account is signed in",
    "Stay signed in, so it can keep reading while you're away",
    "If you turn on acting, it asks once more to send and change mail and events",
)
#: What using the publisher's app registration means for the person (the host shows it while that registration is used).
#: The callback addresses the publisher's registration allows (a loopback host matches any port). At any other address
#: (another base path, a hosted app) PM Cockpit asks the person for their own registration instead.
DEFAULT_REDIRECTS = ("http://localhost/api/sign-ins/callback", "http://127.0.0.1/api/sign-ins/callback")
DEFAULT_APP_NOTE = (
    "This uses the add-on publisher's app registration. A work or school account may need its administrator to "
    "approve the app before you can sign in."
)
#: How a person makes their own app registration: a line, or a line with the https page to open for it.
OWN_APP_STEPS = (
    (
        "Register a new app in Microsoft Entra",
        "https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/CreateApplicationBlade",
    ),
    "Supported account types: accounts in any organizational directory and personal Microsoft accounts",
    "Platform: Public client/native (mobile & desktop), with the address shown here as its redirect URI",
    (
        "Under API permissions, add Microsoft Graph delegated permissions Mail.Read, Calendars.Read, User.Read and "
        "offline_access, plus Mail.ReadWrite, Mail.Send and Calendars.ReadWrite for acting",
        "https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade",
    ),
    "Don't create a client secret",
    "Copy the Application (client) ID from the app's Overview and paste it here",
)
#: What reading starts as soon as the person signs in: the inbox, the sent mail and the main calendar.
SOURCES = (
    {"connector": "microsoft/mail", "label": "Your inbox", "settings": {}, "every_minutes": 15},
    {
        "connector": "microsoft/mail",
        "label": "Your sent mail",
        "settings": {"folders": ["sentitems"]},
        "every_minutes": 15,
        "sent": True,
    },
    {"connector": "microsoft/calendar", "label": "Your calendar", "settings": {}, "every_minutes": 15},
)
MAIL_NOT_ALLOWED = "Reading mail wasn't allowed when you signed in. Sign in again and allow it."
CALENDAR_NOT_ALLOWED = "Reading your calendar wasn't allowed when you signed in. Sign in again and allow it."


def account(context: Any) -> str:
    """The signed-in account as `Name <address>`, or just the address when there is no name."""
    token = context.access_token(SIGN_IN)
    response = context.web.get(
        f"{GRAPH}/me",
        params={"$select": "displayName,mail,userPrincipalName"},
        headers={"Authorization": f"Bearer {token}"},
    )
    try:
        body = response.json()
    except ValueError:
        body = None
    if response.status >= 300:
        raise service_error(response.status, body, "Microsoft")
    if not isinstance(body, dict):
        raise ConnectorError("outage", "Microsoft: the answer wasn't readable")
    who = person({"name": body.get("displayName"), "address": body.get("mail") or body.get("userPrincipalName")})
    if not who:
        raise ConnectorError("outage", "Microsoft: the answer named no account")
    return who
