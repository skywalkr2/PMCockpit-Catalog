"""The exact Microsoft Graph request each approved act makes, and the request that undoes it.

Pure functions: nothing here reaches the network, reads a context or registers anything. A channel looks up what is
needed (a folder, a draft's body, a message's categories), asks for the request here, and makes it. Paths are
relative to the Graph address. Nothing here deletes or bins mail.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, date, datetime, timedelta
from typing import Any
from urllib.parse import quote

from engine.plugin_api import OutgoingAct

MESSAGE_ACTIONS = ("send", "reply", "reply_all", "forward")
MAILBOX_ACTIONS = ("archive", "move", "label", "mark_read")
ANSWERS = {"accepted": "accept", "tentative": "tentativelyAccept", "declined": "decline"}
#: The property every created draft and event carries, so a lost answer can be settled by searching for it.
MARKER_ID = "String {6c3b8e4e-5a4f-4b0a-9a3e-2f1d7c9b8a10} Name pmcAttempt"
#: Folders an act may never move mail to: they would delete it (compared without spaces, in lower case).
_BINS = ("deleteditems", "recoverableitemsdeletions", "trash", "bin")
_CREATE_REPLY = {"reply": "createReply", "reply_all": "createReplyAll", "forward": "createForward"}

Request = tuple[str, str, dict[str, str], dict[str, Any] | None]


def attempt_hash(attempt_key: str) -> str:
    """The first 32 hex characters of the key's SHA-256."""
    return hashlib.sha256(attempt_key.encode("utf-8")).hexdigest()[:32]


def marker(attempt_key: str) -> list[dict[str, str]]:
    """The `singleValueExtendedProperties` entry that marks what an attempt created."""
    return [{"id": MARKER_ID, "value": attempt_hash(attempt_key)}]


def is_bin(name: str) -> bool:
    """Whether a folder name is one that deletes mail."""
    return "".join(name.split()).casefold() in _BINS


# ---- messages ---------------------------------------------------------------------------------------------------


def _plain(value: str, what: str) -> str:
    if "\r" in value or "\n" in value:
        raise ValueError(f"{what} has a line break in it")
    return value


def _people(act: OutgoingAct, role: str) -> list[dict[str, Any]]:
    return [
        {"emailAddress": {"address": _plain(r.address, "A recipient's address")}}
        for r in act.recipients
        if r.role == role
    ]


def _checked(act: OutgoingAct) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    if act.kind != "message":
        raise ValueError(f"A {act.kind} act is not a message")
    if act.action not in MESSAGE_ACTIONS:
        raise ValueError(f"Outlook mail can't do '{act.action}' as a message")
    to, cc = _people(act, "to"), _people(act, "cc")
    if not to and not cc:
        raise ValueError("The message has no recipients")
    return to, cc


def _recipients(to: list[dict[str, Any]], cc: list[dict[str, Any]]) -> dict[str, Any]:
    found: dict[str, Any] = {}
    if to:
        found["toRecipients"] = to
    if cc:
        found["ccRecipients"] = cc
    return found


def new_draft(act: OutgoingAct, attempt_key: str) -> Request:
    """The request that creates the draft of a new message, with exactly the subject and body approved."""
    to, cc = _checked(act)
    if act.action != "send":
        raise ValueError(f"A '{act.action}' needs the message it answers")
    body = {
        "subject": act.parts.get("subject", ""),
        "body": {"contentType": "Text", "content": act.parts.get("body", "")},
        **_recipients(to, cc),
        "singleValueExtendedProperties": marker(attempt_key),
    }
    return "POST", "/me/messages", {}, body


def original_id(act: OutgoingAct) -> str:
    found = next((a.service_id for a in act.about if a.service_id), None)
    if not found:
        raise ValueError("The act names no message to answer")
    return found


def answer_draft(act: OutgoingAct) -> Request:
    """The request that makes a draft holding the original, for a reply, a reply to all or a forward."""
    _checked(act)
    if act.action not in _CREATE_REPLY:
        raise ValueError(f"A '{act.action}' is not an answer to a message")
    return "POST", f"/me/messages/{quote(original_id(act), safe='')}/{_CREATE_REPLY[act.action]}", {}, {}


def draft_update(act: OutgoingAct, attempt_key: str, quoted: str) -> dict[str, Any]:
    """The body that sets a draft to exactly what was approved: the subject and recipients, the marker, and the
    person's note placed before the quoted original (`quoted`, as text)."""
    to, cc = _checked(act)
    note = act.parts.get("body", "")
    content = f"{note}\n\n{quoted}" if quoted.strip() else note
    return {
        "subject": act.parts.get("subject", ""),
        "body": {"contentType": "Text", "content": content},
        **_recipients(to, cc),
        "singleValueExtendedProperties": marker(attempt_key),
    }


def draft_path(draft_id: str) -> str:
    if not draft_id:
        raise ValueError("The draft has no id")
    return f"/me/messages/{quote(draft_id, safe='')}"


def send_draft(draft_id: str) -> Request:
    """The request that sends a draft: the act itself."""
    return "POST", f"{draft_path(draft_id)}/send", {}, None


# ---- mailbox acts -----------------------------------------------------------------------------------------------


def message_ids(act: OutgoingAct) -> list[str]:
    """The service ids of the messages a mailbox act is about."""
    if act.kind != "mailbox":
        raise ValueError(f"A {act.kind} act is not a mailbox act")
    if act.action not in MAILBOX_ACTIONS:
        raise ValueError(f"Outlook mail can't do '{act.action}' to messages")
    ids = [a.service_id for a in act.about if a.service_id]
    if not ids or len(ids) != len(act.about):
        raise ValueError("The act names no message to change")
    return ids


def folder_name(act: OutgoingAct) -> str:
    """The folder a move names: never empty, never one that deletes mail."""
    name = (act.folder or "").strip()
    if not name:
        raise ValueError("The act names no folder")
    if any(is_bin(part) for part in name.split("/")):
        raise ValueError(f"'{name}' can't be used as a folder")
    return name


def label_name(act: OutgoingAct) -> str:
    name = _plain((act.label or "").strip(), "The label")
    if not name:
        raise ValueError("The act names no label")
    return name


def move_message(message_id: str, destination: str) -> Request:
    """The request that moves a message to a folder (an id or a well-known name)."""
    return "POST", f"/me/messages/{quote(message_id, safe='')}/move", {}, {"destinationId": destination}


def change_message(message_id: str, fields: dict[str, Any]) -> Request:
    return "PATCH", f"/me/messages/{quote(message_id, safe='')}", {}, fields


def read_mark(message_id: str, read: bool) -> Request:
    return change_message(message_id, {"isRead": read})


def with_label(existing: list[str], label: str) -> list[str]:
    return existing if label.casefold() in {c.casefold() for c in existing} else [*existing, label]


def without_label(existing: list[str], label: str) -> list[str]:
    return [c for c in existing if c.casefold() != label.casefold()]


# ---- calendar acts ----------------------------------------------------------------------------------------------


def _calendar_act(act: OutgoingAct, action: str) -> None:
    if act.kind != "calendar":
        raise ValueError(f"A {act.kind} act is not a calendar act")
    if act.action != action:
        raise ValueError(f"A '{act.action}' act is not a calendar '{action}'")


def event_id(act: OutgoingAct) -> str:
    found = next((a.service_id for a in act.about if a.service_id), None)
    if not found:
        raise ValueError("The act names no event")
    return found


def event_path(identifier: str) -> str:
    if not identifier:
        raise ValueError("The act names no event")
    return f"/me/events/{quote(identifier, safe='')}"


def _moment(value: str | None, what: str) -> date | datetime:
    if not value:
        raise ValueError(f"The event has no {what}")
    try:
        if "T" not in value and " " not in value:
            return date.fromisoformat(value)
        moment = datetime.fromisoformat(value)
    except ValueError:
        raise ValueError(f"The event's {what} isn't a date or a time") from None
    if moment.tzinfo is None:
        raise ValueError(f"The event's {what} needs a time zone offset")
    return moment


def _graph_time(value: date | datetime) -> dict[str, str]:
    if isinstance(value, datetime):
        return {"dateTime": value.astimezone(UTC).replace(tzinfo=None).isoformat(), "timeZone": "UTC"}
    return {"dateTime": f"{value.isoformat()}T00:00:00", "timeZone": "UTC"}


def span(act: OutgoingAct) -> dict[str, Any]:
    """`start`, `end` and `isAllDay` for the act's times, in UTC. A bare date is an all-day event."""
    first, last = _moment(act.start, "start"), _moment(act.end, "end")
    if isinstance(first, datetime) != isinstance(last, datetime):
        raise ValueError("The event's start and end must both be dates or both be times")
    if last < first:  # type: ignore[operator]
        raise ValueError("The event ends before it starts")
    if not isinstance(first, datetime) and last == first:
        last = first + timedelta(days=1)  # Graph's all-day end is the day after
    return {"start": _graph_time(first), "end": _graph_time(last), "isAllDay": not isinstance(first, datetime)}


def create_event(act: OutgoingAct, attempt_key: str) -> Request:
    """The request that creates an event with its attendees (invitations go out), any reminder, and the marker."""
    _calendar_act(act, "create")
    if not act.title:
        raise ValueError("The event has no title")
    body: dict[str, Any] = {"subject": act.title, **span(act), "singleValueExtendedProperties": marker(attempt_key)}
    if act.parts.get("body"):
        body["body"] = {"contentType": "Text", "content": act.parts["body"]}
    attendees = [
        {"emailAddress": {"address": _plain(r.address, "An attendee's address")}, "type": "required"}
        for r in act.recipients
    ]
    if attendees:
        body["attendees"] = attendees
    if act.alarm_minutes is not None:
        body["isReminderOn"] = True
        body["reminderMinutesBeforeStart"] = act.alarm_minutes
    calendar = act.calendar
    path = "/me/events" if calendar in (None, "", "own") else f"/me/calendars/{quote(str(calendar), safe='')}/events"
    return "POST", path, {}, body


def undo_create(identifier: str) -> Request:
    """The request that takes a created event back: it is deleted. Only an event; mail is never deleted."""
    return "DELETE", event_path(identifier), {}, None


def move_event(act: OutgoingAct) -> Request:
    """The request that gives an event new times."""
    _calendar_act(act, "move")
    when = span(act)
    return "PATCH", event_path(event_id(act)), {}, when


def cancel_event(act: OutgoingAct) -> Request:
    """The request that cancels an event, with the comment when there is one; the attendees are told."""
    _calendar_act(act, "cancel")
    comment = act.parts.get("comment")
    return "POST", f"{event_path(event_id(act))}/cancel", {}, {"comment": comment} if comment else {}


def answer_event(act: OutgoingAct) -> Request:
    """The request that answers an invitation, with the comment, telling the organizer."""
    _calendar_act(act, "answer")
    if act.answer == "propose":
        raise ValueError("Outlook calendar can't propose a new time")
    verb = ANSWERS.get(act.answer or "")
    if not verb:
        raise ValueError(f"'{act.answer}' isn't an answer to an invitation")
    body: dict[str, Any] = {"sendResponse": True}
    if act.parts.get("comment"):
        body["comment"] = act.parts["comment"]
    return "POST", f"{event_path(event_id(act))}/{verb}", {}, body
