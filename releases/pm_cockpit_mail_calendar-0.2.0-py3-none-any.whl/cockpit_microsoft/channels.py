"""The Outlook mail and calendar channels: how an act the person approved is carried out.

A channel is called only by the host's publisher, for an act the person said yes to. It looks up what the act needs,
makes the requests `acting.py` describes, and answers `ChannelSent`, `ChannelFailed` (only when it is sure nothing
went out) or `ChannelUnknown` (an outage, throttling or a timeout on the request that does the act: it may have gone
through). `status` never says "not sent". Nothing here deletes or bins mail.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any
from urllib.parse import quote, urlsplit

from engine.plugin_api import (
    ChannelContext,
    ChannelFailed,
    ChannelFolder,
    ChannelSent,
    ChannelUndone,
    ChannelUnknown,
    ConnectorError,
    OutgoingAct,
)

from cockpit_mail_calendar_common import scope_granted

from . import acting
from .graph import GRAPH, body_text, find_by_name
from .mail import WELL_KNOWN
from .sign_in import ACTING_SCOPES

MAIL_CHANNEL = "microsoft/mail-channel"
CALENDAR_CHANNEL = "microsoft/calendar-channel"
READ_WRITE, SEND, CALENDARS = ACTING_SCOPES
ACTING_NOT_ALLOWED = (
    "Acting isn't allowed for this account yet. Turn on acting for it again and allow it on Microsoft's page."
)
DRAFT_LEFT = " A draft was left in Drafts."
CANT_TAKE_BACK = "This can't be taken back here. Look in Outlook."
#: The most messages one mailbox act changes (each is its own request).
MAX_MESSAGES = 100
#: The most pages read to list one level of folders.
MAX_FOLDER_PAGES = 10
#: How many levels of child folders the folder list reads (the top level is the first).
MAX_FOLDER_DEPTH = 4
#: The most requests one folder list makes, the excluded folders' lookups and the categories included.
MAX_FOLDER_REQUESTS = 20
#: Folders never offered to move to, by well-known name.
_UNOFFERED = (
    "deleteditems",
    "junkemail",
    "drafts",
    "outbox",
    "sentitems",
    "conversationhistory",
    "recoverableitemsdeletions",
)
#: The longest quoted original kept in a reply, in characters.
MAX_QUOTED = 200_000
#: Graph's error codes that say the sign-in lacks the access this request needs.
_DENIED_CODES = {"ErrorAccessDenied", "Authorization_RequestDenied"}
#: Graph's error codes that say it asked us to wait.
_THROTTLE_CODES = {"ApplicationThrottled", "TooManyRequests", "activityLimitReached"}
_NEVER_FOLDERS = {"deleteditems", "recoverableitemsdeletions"}

Answer = ChannelSent | ChannelFailed | ChannelUnknown
attempt_hash = acting.attempt_hash


class _Stop(Exception):
    """Ends the work with this answer."""

    def __init__(self, answer: Answer):
        super().__init__(str(answer))
        self.answer = answer


def _codes(err: ConnectorError | None, body: Any = None) -> list[str]:
    """Graph's own error code from an error body (`error.code`). Codes only, never the message."""
    if body is None and err is not None:
        body = err.json()
    error = body.get("error") if isinstance(body, dict) else None
    code = error.get("code") if isinstance(error, dict) else None
    return [code] if isinstance(code, str) and code else []


def _code_words(codes: list[str]) -> str:
    code = next((c for c in codes if c.replace("_", "").replace("-", "").isalnum() and len(c) <= 80), None)
    return code or "none"


def _json(content: bytes) -> Any:
    try:
        return json.loads(content)
    except ValueError:
        return None


def _never_deletes_mail(method: str, url: str, body: dict | None, blocked: frozenset[str] = frozenset()) -> None:
    """Refuses any Graph request that could delete or bin mail, whatever asked for it."""
    parts = urlsplit(url)
    if (parts.hostname or "").lower() == "graph.microsoft.com":
        path = parts.path.lower()
        if method == "DELETE" and ("/messages" in path or "/mailfolders" in path):
            raise ValueError("Mail is never deleted or put in the bin")
        if "permanentdelete" in path:
            raise ValueError("Mail is never deleted or put in the bin")
    if isinstance(body, dict):
        for key in ("destinationId", "parentFolderId"):
            target = body.get(key)
            if isinstance(target, str) and (target in blocked or "".join(target.split()).casefold() in _NEVER_FOLDERS):
                raise ValueError("Mail is never deleted or put in the bin")


class _Call:
    """The requests of one call, with the account's token. `lookup` is a GET made before the act; `prepare` makes
    something that is not the act (a draft); `act` is the request that does it, whose failure to answer may mean it
    went through."""

    def __init__(self, context: ChannelContext, scopes: tuple[str, ...], *, undoing: bool = False):
        self.context = context
        self.undoing = undoing
        self.account = context.account or ""
        self.who = self.account.partition(":")[2] or self.account or "your Microsoft account"
        self.acted = False
        self.draft = False
        self.blocked: frozenset[str] = frozenset()
        self.headers = {"Authorization": f"Bearer {self._token()}", "Prefer": 'IdType="ImmutableId"'}
        granted = set(context.granted or ())
        if not all(scope_granted(granted, scope) for scope in scopes):
            raise _Stop(ChannelFailed("refused", ACTING_NOT_ALLOWED))

    def _token(self) -> str:
        try:
            token = self.context.access_token()
        except ConnectorError as err:
            if err.kind == "offline":
                raise _Stop(ChannelFailed("offline", "Couldn't reach Microsoft. Check the connection.")) from None
            if err.kind in ("auth", "no_access"):
                raise _Stop(ChannelFailed("auth", f"Sign in to {self.who} again.")) from None
            raise _Stop(ChannelFailed("outage", "Microsoft's sign-in couldn't be renewed just now.")) from None
        if not token:
            raise _Stop(ChannelFailed("auth", f"Sign in to {self.who} again."))
        return token

    # ---- requests ------------------------------------------------------------------------------------------------

    def lookup(self, path: str, params: dict | None = None) -> dict:
        """A GET made before the act (a full address, such as a next link, is used as it is). Returns the decoded JSON
        object; any failure is `ChannelFailed`."""
        _, body = self._send("GET", path, params, None, acts=False)
        if not isinstance(body, dict):
            raise _Stop(ChannelFailed("outage", "Microsoft's answer couldn't be read."))
        return body

    def prepare(self, request: acting.Request) -> Any:
        """A request that makes or sets up something but is not the act (a draft). A failure is `ChannelFailed`."""
        method, path, params, body = request
        return self._send(method, path, params, body, acts=False)[1]

    def act(self, request: acting.Request, *, gone_ok: bool = False) -> tuple[int, Any]:
        """The request that does the act. With `gone_ok`, an event that is already gone (404 or 410) is done."""
        method, path, params, body = request
        _never_deletes_mail(method, GRAPH + path, body, self.blocked)  # before anything is marked as made
        self.acted = not self.undoing
        return self._send(method, path, params, body, acts=not self.undoing, gone_ok=gone_ok)

    def _send(
        self, method: str, path: str, params: dict | None, body: dict | None, *, acts: bool, gone_ok: bool = False
    ) -> tuple[int, Any]:
        url = path if path.startswith("https://") else GRAPH + path
        _never_deletes_mail(method, url, body, self.blocked)
        web = self.context.web
        call: Callable[..., Any] = {"GET": web.get, "POST": web.post, "PATCH": web.patch, "DELETE": web.delete}[method]
        arguments: dict[str, Any] = {"headers": self.headers}
        if params:
            arguments["params"] = params
        if body is not None:
            arguments["json"] = body
        try:
            response = call(url, **arguments)
        except ConnectorError as err:
            if gone_ok and err.kind == "not_found":
                return 404, None
            raise _Stop(self._from_error(err, acts)) from None
        status = response.status
        decoded = _json(response.content) if response.content else None
        if 200 <= status < 300:
            return status, decoded
        if gone_ok and status in (404, 410):
            return status, decoded
        if status == 401:
            raise _Stop(ChannelFailed("auth", f"Sign in to {self.who} again."))
        if status == 408 or not 400 <= status < 500 or status == 429:
            # A timeout, throttling, a server error, a redirect or anything else unexpected: no clear answer.
            raise _Stop(self._unclear(acts, f"Microsoft answered {status}"))
        codes = _codes(None, decoded)
        if _THROTTLE_CODES & set(codes):
            raise _Stop(self._unclear(acts, "Microsoft asked to wait"))
        raise _Stop(ChannelFailed("refused", self._refusal(status, codes)))

    def _unclear(self, acts: bool, why: str) -> Answer:
        if acts:
            return ChannelUnknown()
        return ChannelFailed("outage", f"{why}. Try again in a little while.")

    def _refusal(self, status: int | None, codes: list[str]) -> str:
        if _DENIED_CODES & set(codes):
            return ACTING_NOT_ALLOWED
        return f"Microsoft refused it (status {status if status is not None else 'none'}, code {_code_words(codes)})."

    def _from_error(self, err: ConnectorError, acts: bool) -> Answer:
        codes = _codes(err)
        if err.kind == "auth":
            return ChannelFailed("auth", f"Sign in to {self.who} again.")
        if err.kind == "no_access":
            if _THROTTLE_CODES & set(codes):
                return self._unclear(acts, "Microsoft asked to wait")
            return ChannelFailed("refused", self._refusal(err.status, codes))
        if err.kind == "not_found":
            return ChannelFailed("refused", "Microsoft says it isn't there (status 404).")
        if err.kind == "offline":
            return ChannelFailed("offline", "Couldn't reach Microsoft. Check the connection and try again.")
        # outage, throttled, or anything else: the service did not answer clearly.
        return self._unclear(acts, "Microsoft didn't answer clearly")


def _run(
    context: ChannelContext, scopes: tuple[str, ...], work: Callable[[_Call], Answer], *, undoing: bool = False
) -> Answer:
    """Runs `work` with a call. A refusal before any request is `refused`; the same after the act's request was made
    is `ChannelUnknown`, because the act may have gone through. A definite failure after a draft was made says the
    draft was left in Drafts."""
    call: _Call | None = None
    try:
        call = _Call(context, scopes, undoing=undoing)
        answer = work(call)
    except _Stop as stop:
        answer = stop.answer
    except ValueError as err:
        answer = ChannelUnknown() if call is not None and call.acted else ChannelFailed("refused", str(err))
    if call is not None and call.draft and isinstance(answer, ChannelFailed):
        return ChannelFailed(answer.kind, answer.reason + DRAFT_LEFT)
    return answer


def _sent_id(body: Any, fallback: str | None = None) -> Answer:
    found = body.get("id") if isinstance(body, dict) else None
    if isinstance(found, str) and found:
        return ChannelSent(found)
    # It was accepted but the answer didn't say which: status can find it by its key.
    return ChannelSent(fallback) if fallback else ChannelUnknown()


def _each(call: _Call, items: list[str], make: Callable[[str], acting.Request]) -> None:
    """Makes the act's request for each item. A definite failure after the first item changed leaves the act
    partly done, which is `ChannelUnknown`, never a clean failure."""
    for number, item in enumerate(items):
        try:
            call.act(make(item))
        except _Stop as stop:
            if number and not call.undoing and isinstance(stop.answer, ChannelFailed):
                raise _Stop(ChannelUnknown()) from None
            raise


# ---- mail -------------------------------------------------------------------------------------------------------


def _send_message(call: _Call, act: OutgoingAct, attempt_key: str) -> Answer:
    if act.action == "send":
        request = acting.new_draft(act, attempt_key)
        made = call.prepare(request)
        call.draft = True
        draft = made.get("id") if isinstance(made, dict) else None
    else:
        acting.draft_update(act, attempt_key, "")  # fit to send? checked before anything is made
        made = call.prepare(acting.answer_draft(act))
        call.draft = True
        draft = made.get("id") if isinstance(made, dict) else None
        if not isinstance(draft, str) or not draft:
            raise _Stop(ChannelFailed("outage", "Microsoft's answer couldn't be read."))
        body = made.get("body") if isinstance(made, dict) else None
        if not isinstance(body, dict):
            body = call.lookup(acting.draft_path(draft), {"$select": "body"}).get("body")
        quoted = body_text(body, MAX_QUOTED)
        call.prepare(("PATCH", acting.draft_path(draft), {}, acting.draft_update(act, attempt_key, quoted)))
    if not isinstance(draft, str) or not draft:
        raise _Stop(ChannelFailed("outage", "Microsoft's answer couldn't be read."))
    call.act(acting.send_draft(draft))
    return ChannelSent(draft)


def _folder_id(call: _Call, name: str) -> str:
    """The id of the folder the person named: a well-known name, or the path of display names walked down."""
    parts = [part.strip() for part in name.split("/") if part.strip()]
    if len(parts) == 1 and parts[0].casefold() in WELL_KNOWN:
        found = call.lookup(f"/me/mailFolders/{quote(parts[0].casefold(), safe='')}", {"$select": "id"}).get("id")
        if not isinstance(found, str) or not found:
            raise _Stop(ChannelFailed("outage", "Microsoft's answer couldn't be read."))
        return found
    if len(parts) == 1 and len(parts[0]) >= 20 and " " not in parts[0]:
        # It may be a folder id as the folder list gave it; if Graph has no such folder it is a name.
        try:
            found = call.lookup(f"/me/mailFolders/{quote(parts[0], safe='')}", {"$select": "id"}).get("id")
        except _Stop as stop:
            if not (isinstance(stop.answer, ChannelFailed) and stop.answer.kind == "refused"):
                raise
        else:
            if isinstance(found, str) and found:
                return found
    parent: str | None = None
    for part in parts:
        url: str | None = (
            "/me/mailFolders" if parent is None else f"/me/mailFolders/{quote(parent, safe='')}/childFolders"
        )
        params: dict | None = {"$select": "id,displayName", "$top": "100"}
        listed: dict[str, str] = {}
        for _ in range(MAX_FOLDER_PAGES):
            if not url:
                break
            body = call.lookup(url, params)
            for entry in body.get("value") if isinstance(body.get("value"), list) else []:
                if isinstance(entry, dict) and isinstance(entry.get("id"), str):
                    listed[entry["id"]] = str(entry.get("displayName") or "")
            url, params = body.get("@odata.nextLink"), None
        parent = find_by_name(part, listed)
        if parent is None:
            raise ValueError(f"There is no folder named '{name}' in this mailbox")
    if parent is None:
        raise ValueError("The act names no folder")
    return parent


def _page_of(call: _Call, url: str, params: dict | None) -> tuple[list[dict], str | None]:
    body = call.lookup(url, params)
    value = body.get("value")
    link = body.get("@odata.nextLink")
    return [e for e in value if isinstance(e, dict)] if isinstance(value, list) else [], (
        link if isinstance(link, str) and link else None
    )


def folders(account: str, context: ChannelContext) -> list[ChannelFolder] | ChannelFailed:
    """The folders (with their child folders, as paths) and categories Move to and Label offer. Read-only, bounded
    in depth and in requests; the bin, junk, drafts, outbox, sent and similar folders are never offered."""

    def work(call: _Call) -> Any:
        budget = [MAX_FOLDER_REQUESTS - 1]  # one is kept for the categories

        def spend() -> bool:
            budget[0] -= 1
            return budget[0] >= 0

        skipped: set[str] = set()
        for well_known in _UNOFFERED:
            if not spend():
                break
            try:
                found = call.lookup(f"/me/mailFolders/{well_known}", {"$select": "id"}).get("id")
            except _Stop as stop:
                if isinstance(stop.answer, ChannelFailed) and stop.answer.kind == "refused":
                    continue  # this mailbox has no such folder
                raise
            if isinstance(found, str) and found:
                skipped.add(found)
        listed: list[tuple[str, str]] = []
        level: list[tuple[str, str | None]] = [("", None)]  # (path so far, folder id) to read the children of
        for _ in range(MAX_FOLDER_DEPTH):
            following: list[tuple[str, str | None]] = []
            for prefix, parent in level:
                url: str | None = (
                    "/me/mailFolders" if parent is None else f"/me/mailFolders/{quote(parent, safe='')}/childFolders"
                )
                params: dict | None = {"$select": "id,displayName,childFolderCount", "$top": "100"}
                while url and spend():
                    entries, url = _page_of(call, url, params)
                    params = None
                    for entry in entries:
                        ident, shown = entry.get("id"), entry.get("displayName")
                        if not isinstance(ident, str) or not ident or ident in skipped:
                            continue
                        if not isinstance(shown, str) or not shown or acting.is_bin(shown):
                            continue
                        path = f"{prefix}/{shown}" if prefix else shown
                        listed.append((ident, path))
                        if entry.get("childFolderCount"):
                            following.append((path, ident))
            level = following
            if not level:
                break
        found_folders = [ChannelFolder(id=i, name=n, kind="folder") for i, n in listed]
        labels: list[ChannelFolder] = []
        try:
            entries, _ = _page_of(call, "/me/outlook/masterCategories", None)
        except _Stop as stop:
            if not (isinstance(stop.answer, ChannelFailed) and stop.answer.kind == "refused"):
                raise  # a refused read lists folders only
        else:
            names = {e["displayName"] for e in entries if isinstance(e.get("displayName"), str) and e["displayName"]}
            labels = [ChannelFolder(id=n, name=n, kind="label") for n in names]
        return sorted(found_folders + labels, key=lambda f: (f.name.casefold(), f.name, f.kind))

    return _run(context, (), work)  # type: ignore[return-value]


def _forbid_bin(call: _Call) -> None:
    """Learns which folder is Deleted Items, so no move can go there under any name."""
    found = call.lookup("/me/mailFolders/deleteditems", {"$select": "id"}).get("id")
    if isinstance(found, str) and found:
        call.blocked = call.blocked | {found}


def _parent_folder(call: _Call, message_id: str) -> str:
    found = call.lookup(f"/me/messages/{quote(message_id, safe='')}", {"$select": "parentFolderId"}).get(
        "parentFolderId"
    )
    if not isinstance(found, str) or not found:
        raise _Stop(ChannelFailed("outage", "Microsoft's answer couldn't be read."))
    return found


def _categories(call: _Call, message_id: str) -> list[str]:
    found = call.lookup(f"/me/messages/{quote(message_id, safe='')}", {"$select": "categories"}).get("categories")
    return [c for c in found if isinstance(c, str)] if isinstance(found, list) else []


def _set_categories(call: _Call, ids: list[str], change: Callable[[list[str]], list[str]]) -> None:
    """Sets each message's categories to `change` of what it has, reading all of them before changing any."""
    before = {i: _categories(call, i) for i in ids}
    _each(
        call,
        [i for i in ids if change(before[i]) != before[i]],
        lambda i: acting.change_message(i, {"categories": change(before[i])}),
    )


def _change_mailbox(call: _Call, act: OutgoingAct) -> Answer:
    ids = acting.message_ids(act)
    if len(ids) > MAX_MESSAGES:
        raise ValueError(f"Outlook changes at most {MAX_MESSAGES} messages at a time")
    if act.action in ("archive", "move"):
        if act.action == "move":
            destination = acting.folder_name(act)
            _forbid_bin(call)
            destination = _folder_id(call, destination)
            if destination in call.blocked:
                raise ValueError("Mail is never deleted or put in the bin")
        else:
            destination = "archive"
        came_from = _parent_folder(call, ids[0])
        _each(call, ids, lambda i: acting.move_message(i, destination))
        return ChannelSent(json.dumps({"from": came_from}))
    if act.action == "label":
        label = acting.label_name(act)
        _set_categories(call, ids, lambda have: acting.with_label(have, label))
    else:
        _each(call, ids, lambda i: acting.read_mark(i, True))
    return ChannelSent(ids[0])


def send_mail(act: OutgoingAct, attempt_key: str, context: ChannelContext) -> Answer:
    """Carry out an approved message or mailbox act."""

    def work(call: _Call) -> Answer:
        if act.kind == "message":
            return _send_message(call, act, attempt_key)
        if act.kind == "mailbox":
            return _change_mailbox(call, act)
        raise ValueError(f"Outlook mail can't do a {act.kind} act")

    scopes = (READ_WRITE, SEND) if act.kind == "message" else (READ_WRITE,)
    return _run(context, scopes, work)


# ---- calendar ---------------------------------------------------------------------------------------------------


def _calendar_act(call: _Call, act: OutgoingAct, attempt_key: str) -> Answer:
    if act.action == "create":
        _, answer = call.act(acting.create_event(act, attempt_key))
        return _sent_id(answer)
    if act.action == "move":
        request = acting.move_event(act)
    elif act.action == "cancel":
        request = acting.cancel_event(act)
    elif act.action == "answer":
        request = acting.answer_event(act)
    else:
        raise ValueError(f"Outlook calendar can't do '{act.action}'")
    call.act(request, gone_ok=act.action == "cancel")
    return ChannelSent(acting.event_id(act))


def send_calendar(act: OutgoingAct, attempt_key: str, context: ChannelContext) -> Answer:
    """Carry out an approved calendar act."""

    def work(call: _Call) -> Answer:
        if act.kind != "calendar":
            raise ValueError(f"Outlook calendar can't do a {act.kind} act")
        return _calendar_act(call, act, attempt_key)

    return _run(context, (CALENDARS,), work)


# ---- undo -------------------------------------------------------------------------------------------------------


def undo_mail(act: OutgoingAct, service_id: str, context: ChannelContext) -> ChannelUndone | ChannelFailed:
    """Take a filing change or read mark back: each message goes back to the folder it came from, the category is
    removed, the read mark is cleared."""

    def work(call: _Call) -> Answer:
        if act.kind != "mailbox" or act.action not in acting.MAILBOX_ACTIONS:
            return ChannelFailed("refused", CANT_TAKE_BACK)
        ids = acting.message_ids(act)
        if len(ids) > MAX_MESSAGES:
            raise ValueError(f"Outlook changes at most {MAX_MESSAGES} messages at a time")
        if act.action in ("archive", "move"):
            try:
                came_from = json.loads(service_id)["from"]
            except (ValueError, TypeError, KeyError):
                came_from = None
            if not isinstance(came_from, str) or not came_from:
                return ChannelFailed("refused", CANT_TAKE_BACK)
            _forbid_bin(call)
            _each(call, ids, lambda i: acting.move_message(i, came_from))
        elif act.action == "label":
            label = acting.label_name(act)
            _set_categories(call, ids, lambda have: acting.without_label(have, label))
        else:
            _each(call, ids, lambda i: acting.read_mark(i, False))
        return ChannelUndone()  # type: ignore[return-value]

    return _run(context, (READ_WRITE,), work, undoing=True)  # type: ignore[return-value]


def undo_calendar(act: OutgoingAct, service_id: str, context: ChannelContext) -> ChannelUndone | ChannelFailed:
    """Take a created event back: it is deleted. Already gone counts as done."""

    def work(call: _Call) -> Answer:
        if act.kind != "calendar" or act.action != "create":
            return ChannelFailed("refused", CANT_TAKE_BACK)
        call.act(acting.undo_create(service_id), gone_ok=True)
        return ChannelUndone()  # type: ignore[return-value]

    return _run(context, (CALENDARS,), work, undoing=True)  # type: ignore[return-value]


# ---- status -----------------------------------------------------------------------------------------------------


def _found(context: ChannelContext, path: str, attempt_key: str) -> Answer:
    """Looks for what an attempt left behind, by its mark. Found is `ChannelSent`; anything else, a failure included,
    is unknown: a search can lag behind a send, so "nothing found" never means "not sent"."""
    wanted = (
        f"singleValueExtendedProperties/Any(ep: ep/id eq '{acting.MARKER_ID}' "
        f"and ep/value eq '{acting.attempt_hash(attempt_key)}')"
    )
    try:
        body = _Call(context, ()).lookup(path, {"$filter": wanted, "$select": "id", "$top": "1"})
    except (_Stop, ValueError):
        return ChannelUnknown()
    items = body.get("value")
    first = items[0] if isinstance(items, list) and items else None
    found = first.get("id") if isinstance(first, dict) else None
    return ChannelSent(found) if isinstance(found, str) and found else ChannelUnknown()


def mail_status(attempt_key: str, context: ChannelContext) -> Answer:
    """What became of a send: the message in Sent Items carrying this attempt's mark, if there is one."""
    return _found(context, "/me/mailFolders/sentitems/messages", attempt_key)


def calendar_status(attempt_key: str, context: ChannelContext) -> Answer:
    """What became of a create: the event carrying this attempt's mark."""
    return _found(context, "/me/events", attempt_key)


__all__ = [
    "ACTING_NOT_ALLOWED",
    "CALENDAR_CHANNEL",
    "MAIL_CHANNEL",
    "attempt_hash",
    "calendar_status",
    "folders",
    "mail_status",
    "send_calendar",
    "send_mail",
    "undo_calendar",
    "undo_mail",
]
